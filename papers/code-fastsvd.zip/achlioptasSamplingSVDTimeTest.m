% For the given matrix A, tests how long it takes to compute the SVD after
% we do uniform Achlioptas sampling for a range of sparsification (p) values,
% versus just the SVD on A
% k is the rank of the SVD approximation
function [baseTime, time] = achlioptasSamplingSVDTimeTest(A, k)

    TRIALS = 2;
    
    %pRange = logspace(log10(0.001), log10(0.5), 5);
    pRange = 1e-4;
    baseTime = zeros(TRIALS, 3);
    time = zeros(TRIALS, length(pRange), 3);
    
    for t = 1 : TRIALS
        % Find the 'base' time, where we don't do any sampling at all
        [u, s, v, bt, method, baseTime(t,:)] = mysvd(A, k);

        i = 1;
        for p = pRange
            B = achlioptasSample(A, p);
            %B = full(B);
            [u, s, v, t0, method, time(t, i, :)] = mysvd(B, k);
            i = i + 1;
        end
    end

    median(baseTime)
    squeeze(median(time))'
    
    time = min(squeeze(median(time)));
    baseTime = min(min(baseTime));
    
    plot(pRange, time, 'o-', pRange, baseTime * ones(length(pRange), 1), 'r-')
    xlabel('Sparsification parameter (p)')
    ylabel('SVD time (seconds)')
    legend({'Uniform sampling' 'No sampling'})
