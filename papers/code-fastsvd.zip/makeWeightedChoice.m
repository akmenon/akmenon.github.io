% Chooses k indices from {1,2,...n}, where index i is picked with
% probability prob(i)
function choices = makeWeightedChoice(prob, k)

    cumulativeProbs = [ 0 cumsum(prob) ];

    % Choose a random interval - generate a rand and find which
    % interval we belong to via binary search
    % If we have chosen an interval due to rounding up, adjust
    % it to choose the right interval (the previous one)
    choices = zeros(1, k);
    for t = 1:k
        r = rand;
        choices(t) = bsearch(cumulativeProbs, r);
        if r < cumulativeProbs(choices(t))
            choices(t) = choices(t) - 1;
        end
    end
