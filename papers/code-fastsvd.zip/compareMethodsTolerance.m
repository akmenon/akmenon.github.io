function compareMethodsTolerance(A)

    % First comparison is with default tolerance levels
    [a,b,c,d] = compareSVDMethods(A, 0.25); % Prevent caching effects
    [ef, e2, s, svd] = compareSVDMethods(A, 0.25);

    % Second comparison is with reduced tolerance and max # of iterations
    opt.tol = 1e-4;
    opt.maxit = 100;
    [ef, e2, s2, svd2] = compareSVDMethods(A, 0.25, opt);

[mean(s+svd,2) mean(s2+svd2,2)]

 %   opt.maxit = 300;
 %   [ef, e2, s3, svd3] = compareSVDMethods(A, 0.25, opt);

 %   opt.tol = 1e-10;
 %   opt.maxit = 100;
 %   [ef, e2, s4, svd4] = compareSVDMethods(A, 0.25, opt);

 %   disp('[ normal tol+it tol it]')
 %   [ mean(s+svd,2) mean(s2+svd2,2) mean(s3+svd3,2) mean(s4+svd4,2) ]
