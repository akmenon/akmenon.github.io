function s = sparsity(A)
    s = length(find(A))/prod(size(A));
