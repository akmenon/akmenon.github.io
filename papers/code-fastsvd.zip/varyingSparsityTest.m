function error = varyingSparsityTest(A)

    As = sparse(A);

    kRange = 0:5:20; kRange(1) = 1;
    %kRange = 1;
    
    %pRange = 0.0625 * 4.^[0:2];
    pRange = 2.^[-4:0];

    timeU = zeros(1, length(pRange));
    timeNU = zeros(1, length(pRange));

    % Error for uniform and non-uniform
    baseError = zeros(1, length(kRange));
    errorU = zeros(length(pRange), length(kRange));
    errorNU = zeros(length(pRange), length(kRange));

[U,S,V] = svds(A, max(kRange));
norm(U*S*V' - A, 'fro')

% Let MATLAB memoize the functions
achlioptasSample(rand(5),1);
achlioptasAdaptiveSample(rand(5),1);

    pCount = 1;
    for p = pRange
        kCount = 1;
        
        % Random sampling of the data in A    
        tic
        B = achlioptasSample(As, p);
        [U1, S1, V1] = svds(B, max(kRange));
        clear('B');
        timeU(pCount) = toc;
        disp(sprintf('svd computation time for p=%6.4f = %6.2f', p, toc));

        tic
        B = achlioptasAdaptiveSample(As, p);
        [U2, S2, V2] = svds(B, max(kRange));
        clear('B');
        timeNU(pCount) = toc;
        disp(sprintf('svd computation time for p=%6.4f = %6.2f', p, toc));        

        for k = kRange    
            tic
            Bk = U1(:, 1:k) * S1(1:k, 1:k) * transpose(V1(:, 1:k));
            timeU(pCount) = timeU(pCount) + toc;
            disp(sprintf('approximation computation time = %6.2f', toc));

            tic
            errorU(pCount, kCount) = norm(As - Bk, 'fro');
            disp(sprintf('norm computation time = %6.2f\n', toc));

            tic
            Bk = U2(:, 1:k) * S2(1:k, 1:k) * transpose(V2(:, 1:k));
            timeNU(pCount) = timeNU(pCount) + toc;
            disp(sprintf('approximation computation time = %6.2f', toc));
            toc;            

            tic
            errorNU(pCount, kCount) = norm(As - Bk, 'fro');
            disp(sprintf('norm computation time = %6.2f\n', toc));

            kCount = kCount + 1;
        end
        pCount = pCount + 1;
    end

    timeU
    timeNU
    errorU
    errorNU

    pRange
    
    % Plot the errors with different styles
    style = { ['o-b'], ['+-r'], ['*-g'], ['x-c'], ['s-m'], ['d-y'], ['v-k'] };
    for i = 1:length(pRange)
        plot(kRange, errorU(i, :), style{i});
        hold on;
    end

    % Add captions
    legends = {};
    for i = 1:length(pRange)
        legends{i} = sprintf('p = %6.4f', pRange(i));
    end
    legend(legends)
