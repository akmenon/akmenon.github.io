% Dummy 'non-sampler', just returns the original matrix
function B = noSample(A, p)
    B = A;
