% Uniform sampling with Achlioptas' technique
function B = achlioptasSample(A, p)

    [m,n] = size(A);

    if 0 && issparse(A)
        I = find(A);
        Anz = A(I);
        B = sparse(size(A));
        B(I) = Anz .* (1/p * (rand(size(Anz)) < p));
    else
        B = A .* (1/p * (rand(m, n) < p));
    end
