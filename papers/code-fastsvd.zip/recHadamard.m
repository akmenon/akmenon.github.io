function R = recHadamard(x, trimmer, base)

    % Pad x and trimmer with zeros so that the size is a power of 2
    n = 2^ceil(log2(size(x, 1)));
    x = [ x ; zeros(n - size(x, 1), size(x, 2)) ];
    trimmer = [ trimmer zeros(size(trimmer, 1), n - size(trimmer, 2)) ];
    trimmer = sparse(trimmer);

    if nargin == 2
        base = min(n, 128);
    end
    
    global HBASE;
    HBASE = hadamard(base); % Hadamard matrix that is used in the base case
    R = trimmedRecHadamard(x, n, trimmer, base);

%trimmer = sparse(eye(n)); trimmer(2:end, :) = [];
%tic;
%    R1 = trimmer * myRecHadamard(x, n);
%toc

%tic;
%    R2 = trimmedRecHadamard(x, n, trimmer);
%toc

%norm(R1 - R2, 'fro')
%R = R1;


function R = trimmedRecHadamard(x, n, trimmer, base)
    global HBASE;
    if n == base
        %R = trimmer * fwht1d(x);
        R = (trimmer * HBASE) * x;
    else
        %x1 = x(1:n/2,:);
        %x2 = x(n/2+1:end,:);
        P1 = trimmer(:,1:n/2);
        P2 = trimmer(:,n/2+1:end);

        reshaped = reshape(x, n/2, 2, size(x, 2));
        t1 = squeeze(sum(reshaped, 2));
        t2 = -squeeze(diff(reshaped, 1, 2));
        
        R1 = trimmedRecHadamard(t1, n/2, P1, base);
        R2 = trimmedRecHadamard(t2, n/2, P2, base);
        R = R1 + R2;
    end


function R = myRecHadamard(x, n)
    if n == 1
        R = x;
    else
        x1 = x(1:n/2,:);
        x2 = x(n/2+1:end,:);

        R1 = myRecHadamard(x1, n/2);
        R2 = myRecHadamard(x2, n/2);
        R = [ R1 + R2; R1 - R2 ];

        % Alternate computations
        %R = (P1 + P2) * R1 + (P1 - P2) * R2;
        %R = [ myRecHadamard(x1+x2, n/2); myRecHadamard(x1-x2, n/2) ];
    end
