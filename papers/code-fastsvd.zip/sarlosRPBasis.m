% Computes a projection-based SVD approximation
% Given epsilon, the error parameter of the algorithm, and k, the rank of
% the approximation
function B = sarlosRPBasis(A, epsilon, k)

    % Find the matrix SA
    [ m, n ] = size(A);
    r = k / epsilon;
    E = randn(r, m) * A;

    % Find a basis for the rowspace

    B0 = rref(E); % Basis for rowspace
    B = B0;
    B(~any(B0, 2), :) = []; % Remove all zero rows    
    B = orth(B'); % Make the columns of B be an orthonormal basis    
