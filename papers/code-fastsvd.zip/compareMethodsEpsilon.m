function compareMethodsEpsilon(A)

time = cell(1);
errorF = cell(1); error2 = cell(1);
i = 1;
for epsilon = 1./(2.*(1:5))
    disp(sprintf('epsilon = %2.4f', epsilon))
    [ef, e2, t, svdt] = compareSVDMethods(A, epsilon);
    time{i} = [ mean(t, 2) mean(svdt, 2) ];
    errorF{i} = ef;
    error2{i} = e2;
    i = i + 1;
end

time{:}
disp('errorF')
errorF{:}
disp('error2')
error2{:}
