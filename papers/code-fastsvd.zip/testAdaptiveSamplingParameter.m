X = rand(1e3);
pRange = 1 ./ 5.^[0:10];

k = 5;
[u,s,v] = svds(X, k);
n1 = norm(X - u*s*v', 'fro')

n2 = zeros(length(pRange), 1);
sp = zeros(length(pRange), 1);

i = 1;
for p = pRange
    B = achlioptasAdaptiveSample(X, p);
%    B = achlioptasSample(X, p);
    [u,s,v] = svds(B, k);
    n2(i) = norm(X - u*s*v', 'fro');
    sp(i) = 100 * sparsity(B);
    i = i + 1;
end

pRange
n2
sp
