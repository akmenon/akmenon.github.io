% Computes the tf-idf for a document-term matrix
function y = tfidf(x)

    % Get the term frequencies for each term in a document
    [n, m] = size(x);
    z = full(sum(x, 2));
    z(z == 0) = 1;
    tf = x ./ repmat(z, 1, m);

    % Get the number of times each term appears in a document
    z = x;
    z(z ~= 0) = 1; % Make x binary - 1 if a term appears, 0 if not
    N = full(sum(z, 1)); % Columnwise sum tells us how many times a term appears

    idf = repmat(log2(n ./ N), n, 1);

    y = tf .* idf; % y stores the tf-idf
