% Does adaptive sampling with parameter p
function B = achlioptasAdaptiveSample(A, p)

    [m, n] = size(A);
    b = max(max(abs(A)));
    
    if issparse(A)
        I = find(A);
        Anz = A(I);
       
        tau = p * (Anz.^2 / b^2);

        P = min(1, max(tau, sqrt(tau / n) * (8*log(n))^2));
        R = rand(size(P)) < P;
        B = sparse(m, n);
        B(I) = Anz .* R ./ P;
    else
        disp(sprintf('p = %2.4f', p))
        disp(sprintf('other scaling = %2.2f', (8*log(n))^2/sqrt(n)))
        tau = p * (A.^2 / b^2);

        P = min(1, max(tau, sqrt(tau / n) * (8*log(n))^2));
        disp(sprintf('mean probability = %2.2f', mean(mean(P))))
        R = rand(m, n) < P;
        
        P(P == 0) = Inf;
        B = A ./ P;
        
        clear P;
        B = B .* R;
    end

    disp(sprintf('density %% of original = %2.2f', 100*(nnz(B)/nnz(A))))
    disp(sprintf('density of adaptive sample = %2.2f', 100*nnz(B)/numel(B)))
