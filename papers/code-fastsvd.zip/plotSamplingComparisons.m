function plotSamplingComparisons(kRange, values, captions, myylabel, mytitle)

    % Plot the values with different styles
    style = { ['o-b'], ['+-r'], ['*-g'], ['x-c'], ['s-m'], ['d-y'], ['v-k'] };
    for i = 1:size(values, 1)
        plot(kRange, values(i, :), style{i});
        hold on;
    end

    % Add captions
    legend(captions)

    xlabel('k') % x-axis is the k value
    ylabel(myylabel)
    title(mytitle)
