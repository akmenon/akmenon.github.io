% Compares the various SVD approximation methods on the input matrix A
% Returns a structure with the Frobenius error, spectral error, sample time, SVD time and
% total time for all methods, as well as the type of SVD algorithm used for each method
%
% There are two optional parameters:
%  1. kRange is the range of k values, k being the rank of the approximation (default: 1 to 19 in increments of 3)
%  1. myepsilon is the error parameter that appears in the guarantees (default: 0.25)
%  2. svdOpts specifies the optimization tolerance and iteration cap of the SVD calls (default: 1e-100 and 300)
function results = compareSVDMethods(A, kRange, myepsilon, svdOpts)

    global B;

    if nargin == 1
        %kRange = 1:3:19;
        kRange = 19;
    end

    if nargin < 3
        myepsilon = 0.5;
    end

    if nargin < 4
        svdOpts = [];
    end

    warning off PROPACK:NotUsingMex

    [m, n] = size(A);
    AF2 = norm(A, 'fro')^2;
    b = max(max(abs(A)));

    % Controls which methods we compare, split into two categories: sampling and projection
    sampler = { @noSample, @achlioptasSample, @achlioptasAdaptiveSample };
    mySamplers = [ 1 2 3 ];
    numSamplers = length(mySamplers);

    svdFun = { @sarlosSVDFun @drineasSVDFun @tygertSVDFun @nguyenSVDFun };
    myProjectors = [ 1 2 3 4 ];
    numProjectors = length(myProjectors);

    algs = { 'Standard' 'Uniform' 'Adaptive' 'Sarlos' 'Drineas' 'Tygert' 'Nguyen' };
    activeAlgs = '';
    for i = 1 : numSamplers
        activeAlgs = sprintf('%s %s', activeAlgs, algs{mySamplers(i)});
    end
    for i = 1 : numProjectors
        activeAlgs = sprintf('%s %s', activeAlgs, algs{3 + myProjectors(i)});
    end
    disp(sprintf('Comparing algorithms: %s\n', activeAlgs))

    % Sampling probabilities for uniform and non-uniform sampling
    %sampleP = [ 0.25 0.0001 ]; % Faces
    %sampleP = [ 0.5 0.35 ]; % Reuters
    sampleP = [ 0.25 0.0009 ]; % Liberty
    %sampleP = [ 0.45 75000 ]; % Harwell-Boeing
    %sampleP = [ 0.5 100000  ]; % HB2

    % Saves the names of the methods returned
    methods = cell(1);

    sampleErrorF = zeros(numSamplers, length(kRange)); sampleError2 = zeros(numSamplers, length(kRange));
    sampleTime = zeros(numSamplers, length(kRange)); sampleSvdTime = zeros(numSamplers, length(kRange));    
    
    for i = mySamplers
        kCount = 1;
        for k = kRange
            disp(sprintf('sampling method %s', algs{i}))
            disp('---------------------')
            
            if i > 1
                fun = sampler{i};

                % Do a random sampling of the data in A
                p = sampleP(i - 1);
                disp(sprintf('sampling probability = %2.2f', p))

                tic;
                B = fun(A, p);
                sampleTime(i, kCount) = toc;

                disp(sprintf('density %% = %2.2f', 100 * nnz(B) / numel(B)))

                % Try both sparse and dense representation for sampled matrix
                % See paper for results on the effects of representation choice
                [U, S, V, denseTime, method] = mysvd(B, k, svdOpts, 0, 0);
                [U, S, V, sparseTime] = mysvd(sparse(B), k, svdOpts, 0, 0);
                sampleSvdTime(i, kCount) = min([denseTime sparseTime]);
            else
                tic;
                B = A;
                sampleTime(i, kCount) = toc;

                [U, S, V, time, method] = mysvd(B, k, svdOpts, 0, 0);
                sampleSvdTime(i, kCount) = time;
            end
            
            clear('B');
            disp(sprintf('sampling time for method %s = %6.2f', algs{i}, sampleTime(i, kCount)));

            tic;
            Bk = U*S*V';
            disp(sprintf('truncated svd computation time = %6.2f', toc))
            sampleTime(i, kCount) = sampleTime(i, kCount) + toc;

            %disp(sprintf('total approximation computation time = %6.2f', sampleSvdTime(i, kCount)));

            % *Estimate* the 2-norm error between A and Bk
            [nf, n2] = mynorms(A - Bk);
            sampleErrorF(i, kCount) = nf;
            sampleError2(i, kCount) = n2;

            kCount = kCount + 1;
        end

        methods{i} = method;
        %disp(sprintf('this used the method %s', method))
        disp('method done')
        disp(sprintf('---------------------\n'))
    end
    

    % Projection based methods
    % ------------------------
    projectionErrorF = zeros(numProjectors, length(kRange)); projectionError2 = zeros(numProjectors, length(kRange));
    projectionTime = zeros(numProjectors, length(kRange));
    projectionSvdTime = zeros(numProjectors, length(kRange));

    epsilon = { 'myepsilon' 'k/myepsilon^2' 'myepsilon' 'myepsilon' };

    for i = myProjectors
        kCount = 1;
        disp(sprintf('projection method #%d', i))
        disp('---------------------')

        for k = kRange
            [Bk, t, st, method] = svdFun{i}(A, eval(epsilon{i}), k, svdOpts);
            projectionTime(i, kCount) = t;
            projectionSvdTime(i, kCount) = st;
            %disp(sprintf('total approximation computation time = %6.2f', projectionSvdTime(i, kCount)));

            % *Estimate* the 2-norm error between A and Bk
            [nf, n2] = mynorms(A - Bk);
            projectionErrorF(i, kCount) = nf;
            projectionError2(i, kCount) = n2;

            kCount = kCount + 1;
        end

        methods{i + numSamplers} = method;
        %disp(sprintf('this used the method %s', method))
        disp('method done')
        disp(sprintf('---------------------\n'))
    end

    sampleKTime = [sampleTime; projectionTime];
    svdKTime = [sampleSvdTime; projectionSvdTime];

    results.kRange = kRange;
    results.errF = [ sampleErrorF; projectionErrorF ];
    results.err2 = [ sampleError2; projectionError2 ];
    results.sampleTime = sampleKTime;
    results.svdTime = svdKTime;
    results.totalTime = sampleKTime + svdKTime;
    results.methods = methods;

    prettyDisplay(sampleKTime, 'sampleTime');
    prettyDisplay(svdKTime, 'svdTime');
    prettyDisplay(sampleKTime + svdKTime, 'totalTime');
    prettyDisplay([sampleErrorF; projectionErrorF], 'errorF');
    prettyDisplay([sampleError2; projectionError2], 'error2');
    disp(methods)
    disp(sprintf('\n\n'))
    
    plotResults(results)


% Prints out the contents of the matrix X, with the string 'name' used as a description
function prettyDisplay(X, name)
    disp(sprintf('%s = [', name))
    disp(num2str(X))
    disp(']')


    

function [Bk, projTime, svdTime, method] = sarlosSVDFun(A, epsilon, k, svdOpts)

    % Find an orthonormal basis for the row space of a random projection of A
    % Then, get the rank-k approximation to the space
    tic;
    E = sarlosRP(A, epsilon, k);
    P = orth(E');
    B = A*P;
    projTime = toc;

    [u, s, v, svdTime, method] = mysvd(B, min(k, size(B, 2)), svdOpts);

    tic;
    Bk = u*s*v'*P';
    projTime = projTime + toc;


function [Bk, projTime, svdTime, method] = drineasSVDFun(A, epsilon, k, svdOpts)
    
    tic;
    epsilon = ceil(epsilon);
    C = linearTimeSVDSample(A, epsilon, k);
    D = full(C);
    projTime = toc;

    % Size of D is epsilon x epsilon, so we must find the rank epsilon approximation to get the
    % entire SVD
    [U, S, V, svdTime, method] = mysvd(D' * D, epsilon, svdOpts);

    tic;
    U = U ./ sqrt(repmat(diag(S)', epsilon, 1));

    H = C*U;
    H = H(:, 1:k);

    Bk = H*(H'*A);
    projTime = projTime + toc;


function [Bk, projTime, svdTime, method] = tygertSVDFun(A, epsilon, k, svdOpts)

    [U, S, V, svdTime, projTime, method] = tygertPCA(A, k);

    tic;
    Bk = U*S*V';
    projTime = projTime + toc;    
    

function [Bk, projTime, svdTime, method] = nguyenSVDFun(A, epsilon, k, svdOpts)

    [U, S, V, svdTime, projTime, method] = nguyenSVD(A, epsilon, k);

    tic;
    Bk = U*S*V';
    projTime = projTime + toc;


function [nf, n2] = mynorms(A)

%     nf = 0; n2 = 0;
    nf = norm(A, 'fro');
    n2 = normest(A);

