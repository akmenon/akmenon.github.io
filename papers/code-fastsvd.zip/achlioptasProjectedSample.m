function B = achlioptasProjectedSample(A, p)
    P = achlioptasSample(A, p);

    [U, S, V] = mysvd(P, k);
    Pk = U*S*V';

    Pk = orth(Pk');

    % Now project A onto the subspace of its projection
    Bk = A*Pk*Pk';
