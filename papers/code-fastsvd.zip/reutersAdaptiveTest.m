function pqueue = reutersAdaptiveTest()

tic;
x = loadReuters();
x = x(1:1000, :);
toc

[m, n] = size(x);

pqueue = 0:-1:-60000;
z = 0;

[i,j,v] = find(x);
length(v)
s = 1;
for val = v'
    %tic
    z = z + val^2;
    r = rand();
    k = max(s*val^2 / r, s*val^2 / r^2 * ((8*log(n))^4 / n));
    
    if k >= z
        index = bsearch(pqueue, k);
        pqueue(1, index + 1 : end) = pqueue(1, index : end - 1);
        pqueue(1, index) = k;
    end
    
    index = bsearch(pqueue, z);
    pqueue(1, index:end) = -1:-1:-(length(pqueue) - index + 1);
    %toc
end

pqueue = pqueue(pqueue > 0);
