%=======================================================
%FUNCTIONS FOR 1-D SEQUENCY(WALSH),DYADIC(PALEY) AND 
%NATURAL(HADAMARD)ORDERED FAST WALSH-HADAMARD TRANSFORM
%=======================================================

function x = fwht1d(data, trim)

    n = size(data, 1);
    data = [ data; zeros(2^ceil(log(n)) - size(data, 1), size(data, 2)) ];

    if nargin == 1
        x = fhtnat(data);
    else    
        x = fhtTrim(data, trim);
    end

    %x = zeros(size(data));
    %i = 1;
    %for d = data
        %x(:, i) = fhtseq(d);
        %i = i + 1;
    %end

%-------------------------------------------------------
%1D sequency(Walsh)ordered Fast Walsh-Hadamard Transform
%-------------------------------------------------------
function x=fhtseq(data)
% The function implement the 1D sequency(Walsh)ordered 
% fast Walsh-Hadamard transform,
% This algorithm is implemented in N log2 N additions and subtractions. 
% Data sequence length should be an integer power of 2.
% Otherwise last elements will be truncated.
% The inverse transform is the same as the forward transform 
% except for the multiplication factor N.
% 
% Example:
% x=[1 2 1 1]
% y=fhtseq(x)
% 
% Author: Gylson Thomas
% e-mail: gylson_thomas@yahoo.com
% Asst. Professor, Electrical and Electronics Engineering Dept.
% MES College of Engineering Kuttippuram,
% Kerala, India, February 2005.
% copyright 2007.

x=bitrevorder(data);
N=length(x);
k1=N; k2=1; k3=N/2;
for i1=1:log2(N)  % In-place iteration begins here 
    L1=1;
    for i2=1:k2
        for i3=1:k3
            i=i3+L1-1; j=i+k3;
            temp1= x(i); temp2 = x(j); 
            if(mod(i2,2) == 0)
              x(i) = temp1 - temp2;
              x(j) = temp1 + temp2;
            else
              x(i) = temp1 + temp2;
              x(j) = temp1 - temp2;
            end
        end
            L1=L1+k1;
    end
        k1 = k1/2;  k2 = k2*2;  k3 = k3/2;
end
x=inv(N)*x; %Delete this line for inverse transform


%------------------------------------------------------
%1D Dyadic(Paley)ordered Fast Hadamard Transform
%------------------------------------------------------
function x=fhtdya(data)
% The function implement the 1D dyadic (Paley) ordered fast Hadamard transform,
x=bitrevorder(data);
N=length(x);
k1=N; k2=1; k3=N/2;
for i1=1:log2(N)   
    L1=1;
    for i2=1:k2
        for i3=1:k3
            i=i3+L1-1; j=i+k3;
            temp1= x(i); temp2 = x(j); 
            x(i) = temp1 + temp2;
            x(j) = temp1 - temp2;
        end
            L1=L1+k1;
    end
        k1 = k1/2;  k2 = k2*2;  k3 = k3/2;
end
x=inv(N)*x; %Delete this line for inverse transform

%------------------------------------------------------
%1D Natural(Hadamard)ordered Fast Hadamard Transform
%------------------------------------------------------
function x=fhtnat(data)

% The function implement the 1D natural(Hadamard)ordered Fast Hadamard Transform,
N = pow2(floor(log2(size(data, 1))));
x = data';

k1=N; k2=1; k3=N/2;

for i1=1:log2(N)
    L1=1;
    for i2=1:k2
%         for i3=1:k3
%             i = i3 + L1 - 1; j = i + k3;
% 
%             temp1 = x(:,i); temp2 = x(:,j);
%             x(:,i) = temp1 + temp2;
%             x(:,j) = temp1 - temp2;
%         end

        R = [1 : k3];
        I = L1 - 1 + R;
        J = L1 - 1 + k3 + R;
        temp1 = x(:,I);
        temp2 = x(:,J);
        x(:,I) = temp1 + temp2;
        x(:,J) = temp1 - temp2;

        L1=L1+k1;
    end
   k1 = k1/2;  k2 = k2*2;  k3 = k3/2;
end
x = x';
%x=inv(N)*x; %Delete this line for inverse transform


%------------------------------------------------------
% Function for bit reversal
%------------------------------------------------------
function R = bitrevorder(X)
%Rearrange vector X to reverse bit order,upto max 2^k size <= length(X)
[f,e]=log2(length(X));
I=dec2bin(0:pow2(0.5,e)-1);
R=X(bin2dec(I(:,e-1:-1:1))+1);
