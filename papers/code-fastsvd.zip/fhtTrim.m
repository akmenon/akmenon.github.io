% Implements FWHT with only elements in trim retained
% Each column of data is assumed to contain an input point
% We assume that the length of each input point is a power of 2
function x = fhtTrim(data, trim)

N = size(data, 1);
x = data'; % Do this expensive operation once because otherwise we will have to access elements in row major order

T = length(trim);
trim = trim - 1; % Pretend we are using 0-based indexing
trimSort = sort(trim); % Sort so that we can quickly remove duplicates in inner loop
trimBin = dec2bin(trimSort, log2(N)); % Binary expansion for all retained indices

k1=N; k2=1; k3=N/2;

for i1=1:log2(N)
    trimBinI = trimBin(:,i1); % i1st element in binary expansion for all input points
    zeroBin = sum(trimBinI == '0'); % How many elements in binary expansion are zero
    
    i2Old = 0; % Last value of i2
    i2Range = 1 + floor(trimSort / k1);
    for i2 = i2Range
        % Only use unique i2 values (these correspond to individual matrix blocks)
        if i2Old ~= i2
            for i3=1:k3
                i = i3 + (i2 - 1) * k1;
                j = i + k3;
                temp1 = x(:,i); % ith coefficient for all input points
                temp2 = x(:,j); % jth coefficient for all input points

                if zeroBin > 0
                    x(:,i) = temp1 + temp2;
                end
                if zeroBin < T
                    x(:,j) = temp1 - temp2;
                end
            end

            i2Old = i2;
        end
    end
    
%     for i2 = i2Range
%         if i2Old ~= i2
% %             R = 1:k3;
% %             I = R + (i2 - 1) * k1;
% %             J = I + k3;
% %             temp1 = x(:, I);
% %             temp2 = x(:, J);
% 
%             R = 1:k3;
%             I = R + (i2 - 1) * k1;
%             J = I + k3;
%             reshaped = reshape(x(:, [I J]), size(x, 1), length(I), 2);
% 
%             if zeroBin > 0
%                 x(:, I) = squeeze(sum(reshaped, 3));
%             end
%             if zeroBin < T
%                 x(:, J) = squeeze(diff(reshaped, 1, 3));
%             end
%         end
%         i2Old = i2;
%     end    
    
    k1 = k1/2;  k2 = k2*2;  k3 = k3/2;
end

x = x(:, trim + 1);
x = x';
