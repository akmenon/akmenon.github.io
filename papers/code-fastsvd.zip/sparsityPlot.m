function [t1, t2, t3] = sparsityPlot(nonZero)

% c = how many non-zero entries there are
c = nonZero;

%spRange = 0.01:0.05:1;
spRange = 0.01:0.1:1;
%spRange = 0.01;

t1 = zeros(1, length(spRange));
t2 = zeros(1, length(spRange));
t3 = zeros(1, length(spRange));

ctr = 1;
for sp = spRange
   k = c/sp;
   s = floor(sqrt(k));

   % Make a sqrt(k) x sqrt(k) matrix with sp of the entries
   % being non-zero
   A = sprand(s, s, sp);

   size(A)
   length(find(A))

   tic;
   svds(A, floor(s));
   t1(ctr) = toc;

   tic;
   svd(full(A));
   t2(ctr) = toc;

   tic;
   svds(full(A));
   t3(ctr) = toc;

   ctr = ctr + 1;
end
t1 = t1';
t2 = t2';
t3 = t3';
