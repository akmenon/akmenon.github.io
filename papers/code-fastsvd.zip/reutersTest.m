tic;
x = loadReuters();
x = x(1:100, :);
toc

kRange = 1:5;

for k = kRange
    tic;
    [u, s, v] = svds(x, k);
    norm1(k) = norm(x - u*s*v', 2);
    
    p=0.1;
    [m,n]=size(x);
    y = x .* (1/p * binornd(1, 0.1, m, n));
    [u, s, v] = svds(y, k);
    norm2(k) = norm(x - u*s*v', 2);
    
    [ norm1(k) norm2(k) ]
    
    toc
end

norm1
norm2

plot(kRange, norm1, '-*r', kRange, norm2, '-+g')
