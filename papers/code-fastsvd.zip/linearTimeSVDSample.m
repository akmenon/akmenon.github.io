% Returns the sample of columns we need for the linear time SVD algorithm
function C = linearTimeSVDSample(A, c, k)

    % Choose the optimal probabilities based on the SELECT algorithm
    [m, n] = size(A);    
    
    columnNorms = sum(A.^2, 1);
    prob = columnNorms / sum(columnNorms);    
    
%    columns = zeros(1, c);
    
%    D = 0;
%    for i = 1:n
%        D = D + columnNorms(i);
        
        % We want c random columns
%        choices = rand(1, c) <= repmat(columnNorms(i)/D, 1, c);
%        columns(find(choices)) = i;
%    end
 
    columns = makeWeightedChoice(prob, c);   
    C = A(:, columns) ./ sqrt(c * repmat(prob(columns), m, 1));
