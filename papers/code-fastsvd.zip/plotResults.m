function plotResults(varargin)

    %methodsToPlot = 1:7;
    methodsToPlot = [1 4:7];

    if nargin == 1
        results = varargin{1};
    else
        results.kRange = varargin{1};
        results.errF = varargin{2};
        results.err2 = varargin{3};
        results.svdTime = varargin{4};
        results.sampleTime = varargin{5};
    end

    fields = fieldnames(results);
    for i = 2:length(fields) % Skip kRange
        A = results.(fields{i});
        results.(fields{i}) = A(methodsToPlot, :);
    end
    
    captions = {'Standard', 'Uni', 'Non-uni', 'Sarlos', 'Drineas', 'Tygert', 'Nguyen'};
    captions = captions(methodsToPlot);
    
    % Plot all results    
    %subplot(2, 1, 1)
    plotSamplingComparisons(results.kRange, results.errF, captions, '||A - A^*||_F', 'Accuracy')
    
    figure
    
    %subplot(2, 1, 2)
    plotSamplingComparisons(results.kRange, results.err2, captions, '||A - A^*||_2', 'Accuracy')
    
    figure    
    barSamplingTimeComparisons([mean(results.svdTime, 2) mean(results.sampleTime, 2)], captions, 'Time (seconds)', 'Computation time', {'SVD time' 'Other time'})
    colormap(copper)
