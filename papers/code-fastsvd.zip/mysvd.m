% Call the appropriate svd function to find the best rank k approximation to A
% Might be passed in different tolerance and iteration cap than the defaults (1e-10 and 300 resply)
% Can also optionally specify whether we try svds and svd; PROPACK is always used
function [U, S, V, time, method, allTimes] = mysvd(A, k, svdOpts, useSvds, useSvd)
    
    warning off PROPACK:NotUsingMex

    [m,n] = size(A);
    if nargin == 2 || numel(svdOpts) == 0
        svdOpts = [];
        svdOpts.tol = 1e-10;
        svdOpts.maxit = 300;        
    else
        svdOpts.tol
        svdOpts.maxit
    end

    if nargin < 4
        useSvds = 1;
        useSvd = 1;
    end

    if nargin < 5
        useSvd = 1;
    end

    time1 = Inf; U1 = zeros(m, k); S1 = zeros(k); V1 = zeros(n, k);
    if isreal(A)
        tic;
        cd PROPACK
        %disp('using PROPACK')
        [U1, S1, V1] = lansvd(A, k, 'L', svdOpts);
        cd ..
        time1 = toc;
    end

    time2 = Inf; U2 = U1; S2 = S1; V2 = V1;

    % Sparse SVD isn't useful on large dense matrices
    if useSvds && issparse(A) || numel(A) <= 1e6
        %disp('using sparse svd!')
        tic;

        if ~isempty(svdOpts)
    	    [U2, S2, V2] = svds(A, k, 'L', svdOpts);
        else
            [U2, S2, V2] = svds(A, k, 'L');
        end
        time2 = toc;
    end

    time3 = Inf; U3 = U1; S3 = S1; V3 = V1;

    % Only try full SVD if the size is feasible - if the matrix is large and sparse, we
    % don't want to try to store the entire matrix in memory
    if useSvd && ~(issparse(A) && numel(A) >= 1e6)
        
        %disp('using dense svd!')
        tic;
        [U3, S3, V3] = svd(full(A), 'econ');
        U3 = U3(:, 1:k);
        S3 = S3(1:k, 1:k);
        V3 = V3(:, 1:k);
        time3 = toc;                                                                           
    end

    allTimes = [time1 time2 time3];
    disp(sprintf('times = %2.2f %2.2f %2.2f', allTimes))
    [time, i] = min(allTimes);
    methods = { 'PROPACK' 'svds (Arnoldi)' 'svd (QR)'  };
    method = methods{i};
    
    %disp(sprintf('the best method was %s', method))
    disp('*** avoiding sanity check of svd methods ***')

    if 0
        e1 = mean(mean(U1*S1*V1' - U2*S2*V2'));
        e2 = mean(mean(U1*S1*V1' - U3*S3*V3'));
        e3 = mean(mean(U2*S2*V2' - U3*S3*V3'));
        if max(abs(e1), max(abs(e2), abs(e3))) > 1e-4
            disp('******* The SVD methods do not agree ******')
            disp(sprintf('discrepancy = %4.4f, %4.4f, %4.4f', abs(e1), abs(e2), abs(e3)))
            disp(sprintf('%4.4f, %4.4f, %4.4f', norm(A - U1*S1*V1'), normest(A - U2*S2*V2'), normest(A - U3*S3*V3')))
        end
    end

    if isreal(A)
        U = U1; S = S1; V = V1;
    else
        U = U2; S = S2; V = V2;
    end
