function [svdTime, sampleTime] = reutersSparsityTest()

%x = loadReuters;
%[y,i] = sort(full(sum(x)), 'descend');
%X = x(:, i);

X = rand(1e3);

numTesters = 6;
svdTime = zeros(1, numTesters);
sampleTime = zeros(1, numTesters);

C = 40;
exponent = 2;

%cRange = floor(C * exponent.^[0:-1:-log(C)/log(exponent)]);
cRange = [ 250 500 750 1000 ];

ctr = 1;
for c = cRange
   A = X(:, 1:c);

   disp(sprintf('size(A) = %d ', size(A)))
   disp(sprintf('density of A = %2.2f%%', 100 * length(find(A))/prod(size(A))))

   [se,pe,st,sst,pt,pst] = compareSamplingMethods(A);

sst
pst
   sampleTime(ctr, :) = [st; pt]'
   svdTime(ctr, :) = [mean(sst, 2); mean(pst, 2)]'

   ctr = ctr + 1;
end
