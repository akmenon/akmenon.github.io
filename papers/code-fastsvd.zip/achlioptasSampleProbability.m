function p = achlioptasSampleProbability(A, epsilon)

    AF2 = norm(A, 'fro')^2;
    b = full(max(max(abs(A))));
    n = size(A, 2);
    
    disp(sprintf('error = %2.4f', (64/epsilon^2)))
    disp(sprintf('ratio = %2.4f', n * b^2 / AF2))

    p = (64/epsilon^2) * n * b^2 / AF2;
    
    disp(sprintf('p = %2.2f', p))
    disp(sprintf('just to try it = %2.4f', (64/epsilon^2) * (1/(1 + exp(-n*b^2/AF2)) * 1/512)))
