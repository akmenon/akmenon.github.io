function H = linearTimeSVD(A, c, k)

    % Choose the optimal probabilities based on the SELECT algorithm
    [m, n] = size(A);    
    
    columnNorms = sum(A.^2, 1);
    prob = columnNorms / sum(columnNorms);
    
%    columns = zeros(1, c);    
%    D = 0;
%    for i = 1:n
%        D = D + columnNorms(i);
        
        % We want c random columns
%        choices = rand(1, c) <= repmat(columnNorms(i)/D, 1, c);
%        columns(find(choices)) = i;
%    end
    
    % Choose c random columns from A, with given probability weights for
    % each of the columns
    columns = makeWeightedChoice(prob, c);
    %disp(columns)

    C = A(:, columns) ./ sqrt(c * repmat(prob(columns), m, 1));
    
    [U,S,V] = svds(C'*C, c);
    U = U ./ sqrt(repmat(diag(S)', c, 1));

    H = C*U;
    H = H(:, 1:k);
