function barSamplingTimeComparisons(values, captions, myylabel, mytitle, mylegend)

    bar(values, 'stacked')
    set(gca,'XTickLabel', captions)

    xlabel('Method')
    ylabel(myylabel)
    title(mytitle)
    
    if ~isempty(mylegend)
        legend(mylegend)
    end
