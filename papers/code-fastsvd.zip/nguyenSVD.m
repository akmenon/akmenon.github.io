function [u,s,v,svdTime,otherTime,method] = nguyenSVD(A, epsilon, k, beta)

    svdTime = 0; otherTime = 0;    
    
    if nargin < 4
        beta = 0.75;
    end

    tic;
    d = nguyenDimension(A, epsilon, k, beta);

    m = size(A, 1);

    % Rademacher product
    rad = sparse(diag(2*round(rand(m, 1) - 1) - 1)) * A;

    % Downsampler: d random rows of the identity matrix
    Omega = ceil(m * rand(1, d));
    otherTime = toc;

    %disp(sprintf('fwht with downsampling to %d rows', d))
    tic;       
    rad = [ rad; zeros(2^ceil(log2(m)) - m, size(A, 2)) ]; % Padding with zeros to make a power of 2

%clear A;

    %F = 1/sqrt(d) * fwht1d(rad, Omega);
    H = hadamard(2^ceil(log2(m)));
    F = 1/sqrt(d) * H(Omega, :) * rad;
    otherTime = otherTime + toc;
    %disp(toc)

%clear H;
%A = rad(1:size(A, 1), :); A = abs(A);
%clear rad;

    %disp('orthogonalizing')
    tic;
    E = orth(F');
    P = A*E;
    otherTime = otherTime + toc;
    %disp(toc)

    [u,s,v,svdTime,method] = mysvd(P, min(k, size(P, 2)));

    tic;
    v = E * v;
    otherTime = otherTime + toc;
