function R = iterativeHadamard(x)

    m = size(x, 1);

    R = zeros(m, 1 + log2(m));
    R(:, 1) = x(:, 1);

    % Multiplier matrix
    M = zeros(m, m);
    M(sub2ind(size(M), floor(1:0.5:m/2+0.5), 1:m)) = 1;
    M(sub2ind(size(M), m/2+1:m, 1:2:m)) = 1;
    M(sub2ind(size(M), m/2+1:m, 2:2:m)) = -1;
    
    % ???
    %M = sparse(M);

    for j = 2 : 1 + log2(m)
        R(:, j) = M * R(:, j - 1);
    end
    R = R(:, end);

    % Explicit computation
%    R = M^log2(m) * x(:, 1);
