% Given a matrix of points, finds the pairwise distances between all points
% From http://www-h.eng.cam.ac.uk/help/tpl/programs/Matlab/tricks.html
function D = findPairwiseDistances(points)

   K = points*points';
   d = diag(K);
   one = ones(length(d),1);
   D = sqrt(d*one' + one*d' - 2*K);
