% Selects the top k elements from the given vector by k repeated passes
% over the vector (NOT by sorting)
function indices = selectTopElements(x, k)

    indices = zeros(1, k);
    for i = 1:k
        [val, index] = max(x);
        indices(i) = index;
        
        x(index) = [];
    end
