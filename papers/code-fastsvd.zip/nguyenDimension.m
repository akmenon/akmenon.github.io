% Computes the dimension d that we project A onto
% - epsilon is the approximation error
% - k is the rank of the desired approximation
% - beta is the probability of failure
function d = nguyenDimension(A, epsilon, k, beta)

    m = size(A, 1);
    d0 = 1/epsilon * max(k, sqrt(k) * log(2*m/beta)) * max(log(k), log(3/beta));
    
    %d = ceil(5000/7000 * d0); % Faces
    %d = ceil(1500/7000 * d0); % Reuters
    d = ceil(k/epsilon);
    %d = d0;

    disp(sprintf('d = %2.4f ---> %2.4f', d0, d))
