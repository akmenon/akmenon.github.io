% For a given matrix A, plots the SVD computation time as a function of k,
% the # of singular values we desire
% We expect the behaviour to be O(k)
function time = plotKVersusTime(A, kRange)

    if nargin == 1
        kRange = ceil(linspace(1, 100, 5));
    end
    time = zeros(length(kRange), 1);

    warning off PROPACK:NotUsingMex;
    
    i = 1;
    for k = kRange
        cd PROPACK;
        tic;
        [u,s,v] = lansvd(A, k, 'L');
        time(i) = toc;
        cd ..;

        disp(sprintf('time = %2.2f', time(i)))
        i = i + 1;
    end
    
    plot(kRange, time, 'o-')
    xlabel('# of singular values (k)')
    ylabel('SVD computation time (seconds)')
