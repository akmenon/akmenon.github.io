function [A, U, S, V] = createLibertyMatrix(k, n, prec)

    if nargin == 1
        n = 4096;
    end

    cd gram-schmidt;
    U = Gram_Schmidt_Process(randn(n, k + 20));
    V = Gram_Schmidt_Process(randn(n, k + 20));
    cd ..;

    if nargin == 2
        prec = 15;
    end

    S = [ diag(10.^(-prec * [0:k-1]/(k-1))) zeros(k, 20); zeros(20, k) diag(10^-prec * ones(1, 20)) ];
    A = U * S * V';
