% Computes a projection-based SVD approximation
% Given epsilon, the error parameter of the algorithm, and k, the rank of
% the approximation
function Bk = sarlosRPSVD(A, epsilon, k)

svdTime = 0; otherTime = 0;
    % Find the matrix SA
tic;
    [ m, n ] = size(A);
    r = ceil(k / epsilon);

    R = A' * sign(rand(m, r) - 0.5);
    P = orth(R);
    
    B = A*P;
otherTime = toc;
    
    [u,s,v,svdTime] = mysvd(B, k);

tic;
    Bk = (u*s*v')*P';
otherTime = otherTime + toc;

disp(sprintf('%2.2f + %2.2f = %2.2f', svdTime, otherTime, svdTime + otherTime))
