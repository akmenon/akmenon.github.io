function Bk = sarlosTesterMethod(A, epsilon, k)

rand('seed',1497)

    [m n] = size(A);
    r = ceil(k/epsilon);
    S = sign(rand(r,m) - 0.5);

    % Find an orthornomal basis for the rowspace of SA
    % These are now the columns of P
%tic    
    P = orth((S*A)');
%    disp(sprintf('size of basis = %d x %d', size(P, 1), size(P, 2)))
disp(sprintf('orthogonalization = %2.2f', toc))
    
    % B is the projection of A onto the rowspace of SA
%tic    
    B = A*P;
%    disp(sprintf('size of projection = %d x %d', size(B, 1), size(B, 2)))    
disp(sprintf('projection = %2.2f', toc))   
    
%tic
    [Bk, u, s, v] = bestLRApprox(B, k); % Get the best rank-k approximation
disp(sprintf('svd computation = %2.2f', toc))

%tic
    % Rewrite the right singular vectors in terms of the standard basis
%    disp(sprintf('size of v = %d x %d', size(v, 1), size(v, 2)))    
%    disp(sprintf('size of basis = %d x %d', size(P', 1), size(P', 2)))
    v0 = v' * P';
%    disp(sprintf('size of R.S. vectors = %d x %d', size(v0, 1), size(v0, 2)))
    
    % Project A onto the span of the singular vectors
    % Note that the singular vectors are already orthonormal
    Bk = A*v0'*v0;
%    disp(sprintf('size of result = %d x %d', size(Bk, 1), size(Bk, 2)))    
disp(sprintf('final projection = %2.2f', toc))    
    
% tic
%     P = orth(A'*S'); % Find an orthornomal basis for the rowspace of SA
%     P = orth(P*P'); % Get an orthonormal projection matrix for the subspace
% disp(sprintf('orthogonalization = %2.2f', toc))
% 
% tic
%     B = A*P; % Project A onto the rowspace of SA
% disp(sprintf('projection = %2.2f', toc))
% disp(sprintf('B: %d x %d', size(B, 1), size(B, 2)))
% 
% tic
%     [Bk, u, s, v] = bestLRApprox(B, k); % Get the best rank-k approximation
% disp(sprintf('svd computation = %2.2f', toc))
% 
% disp(sprintf('Bk: %d x %d', size(Bk, 1), size(Bk, 2)))
% 
%     V = v';
%     V = [V zeros(size(V, 1), n - size(V, 2))];
%     
%     Bk = A*V'*V;
   

% 
% tic
%     P = v' * eye(size(v', 2), n); % Project the k right singular vectors onto the basis for R^n
% size(v')
% size(P)
%     Bk = A * (P' * P); % Project A onto the space spanned by the right singular vectors
% disp(sprintf('basis transformation = %2.2f', toc))
