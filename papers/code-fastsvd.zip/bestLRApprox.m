function [Ak, u, s, v] = bestLRApprox(A, k)
    if issparse(A)
        [u, s, v] = svds(A, k);
        Ak = u*s*v';
    else
        [u, s, v] = svd(A, 'econ');
        Ak = u(:, 1:k) * s(1:k, 1:k) * v(:, 1:k)';
    end
