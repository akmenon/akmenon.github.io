n = 100;
k = 10;

A = rand(n);

H = linearTimeSVD(A, 2*k, k);
Z = H*H'*A;
disp(norm(A-Z,'fro'));

[U,S,V] = svds(A,k);
disp(norm(A-U*S*V','fro'));
