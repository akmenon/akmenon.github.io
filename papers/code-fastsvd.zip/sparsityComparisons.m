A = rand(1e3);
p = 10.^[0:-1:-16];

density = zeros(1, length(p));
error = zeros(1, length(p));

for i = 1:length(p)
    Ap = achlioptasSample(A, p(i));
    B = bestLRApprox(Ap, 1);
    
    density(i) = 100 * nnz(Ap) / numel(Ap);
    error(i) = norm(A - B, 'fro');
end

log(1./p)
density
error
