function out = dec2binvec(x, n)

    out = dec2bin(x, n);
    out = logical(str2num([fliplr(out);blanks(length(out))]')');
