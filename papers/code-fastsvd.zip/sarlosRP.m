% Computes a random projection for the Sarlos method, given
% an epsilon and k
function E = sarlosRP(A, epsilon, k)

    % Find the matrix SA
    [ m, n ] = size(A);
    r = ceil(k / epsilon);

    % Use the random +- 1 matrix
    E = sign(rand(r, m) - 0.5) * A; 
