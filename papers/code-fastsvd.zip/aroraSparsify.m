function A = aroraSparsify(A, epsilon)

    [n m] = size(A);
    indices = find(abs(A) <= epsilon/sqrt(n));

    R = (sqrt(n)*abs(A(indices))/epsilon)';
    change = find(rand(1, length(indices)) >= R);
    A(indices(change)) = 0;
