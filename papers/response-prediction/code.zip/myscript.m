function [weights, estimates, paramsOpts] = myscript(CTrain, VTrain, CTest, VTest, k, optional)

    x = setprod([1e-9], [1e-9], [0]);
    LAMBDA = 1:size(x,1);
    lambdaU = x(:,1); lambdaV = x(:,2); lambdaPoisson = x(:,3);

    MU = [0 1e-6 1e-4 1e-2 1e2 1e4 1e6];
    NU = [0];
    MAX_ITER = 500;

    [m,n] = size(CTrain);

    if nargin < 5, k = 2; end; % # of latent features learned

    if nargin < 6, optional = []; end;

    if ~isfield(optional, 'alphaSPrior') || numel(optional.alphaSPrior) == 0, alphaSPrior = speye(m); else alphaSPrior = optional.alphaSPrior; end;
    if ~isfield(optional, 'betaSPrior'), betaSPrior = speye(n); else betaSPrior = optional.betaSPrior; end;
    if ~isfield(optional, 'alphaPathRelation'), alphaPathRelation = speye(m); betaPathRelation = speye(n); else alphaPathRelation = optional.alphaPathRelation; betaPathRelation = optional.betaPathRelation; end;

    q = 1; % Rank of similarity matrix approximation

    noBias = 0;

%%
    % Control which methods we will run
    runSVD = 0;
    runWeightedSVD = 0;
    runLFL = 1;
    runLFLResidual = 0;
    runLFLSimilarity = 0 && sum(MU) > 0;

    runStr = 'running methods:';
    if runSVD, runStr = sprintf('%s SVD,', runStr); end;
    if runWeightedSVD, runStr = sprintf('%s weighted SVD,', runStr); end;
    if runLFL, runStr = sprintf('%s LFL,', runStr); end;
    if runLFLResidual, runStr = sprintf('%s LFL-Residual,', runStr); end;
    if runLFLSimilarity, runStr = sprintf('%s LFL-Similarity', runStr); end;
    runStr = sprintf('%s for %d iterations', runStr, MAX_ITER);
    disp(runStr)

%%
    % Empirical CTR estimate
    E = CTrain ./ max(1, VTrain); % For 0 views, we'll start off predicting CTR of 0...
    %ESmooth = truncateTo01(E); % ...but then we'll try to smooth out the estimate slightly
    ESmooth = max(min(nonzeros(E)), min(E, 0.05));

%%
    % SVD estimates
    if runSVD
        [UE,SE,VE] = svds(E, k); svdEstimate = UE(:,1:k)*UE(:,1:k)'*E;
        [UE,SE,VE] = svds(ESmooth, k); svdSmoothEstimate = UE(:,1:k)*UE(:,1:k)'*ESmooth;

    %	InvSigmoid = log(ESmooth./(1 - ESmooth)); [UI,SI,VI] = svd(InvSigmoid); svdLogitEstimate = sigmoid(UI(:,1:k)*UI(:,1:k)'*InvSigmoid);
    %	InvSigmoid = truncateTo01(log(E./(1 - E))); [UI,SI,VI] = svd(InvSigmoid); svdLogitEstimate = sigmoid(UI(:,1:k)*UI(:,1:k)'*InvSigmoid);    
        E0 = min(1-eps,max(eps, E)); InvSigmoid = log(E0./(1 - E0)); [UI,SI,VI] = svds(InvSigmoid, k); svdLogitEstimate = sigmoid(UI(:,1:k)*UI(:,1:k)'*InvSigmoid);    

        [UV,SV,VV] = svds(VTrain, k); [UC,SC,VC] = svds(CTrain, k); svdSplitEstimate = (UC(:,1:k)*UC(:,1:k)'*CTrain)./(UV(:,1:k)*UV(:,1:k)'*VTrain);
    %	T1 = UC(:,1:k)*UC(:,1:k)'*CTrain; T2 = UV(:,1:k)*UV(:,1:k)'*VTrain; svdSplitEstimate = truncateTo01(T1)./truncateTo01(T2);

        [UN,SN,VN] = svds(VTrain - CTrain, k); [UC,SC,VC] = svds(CTrain, k); svdSplitEstimate2 = 1./(1 + (UN(:,1:k)*UN(:,1:k)'*(VTrain - CTrain))./(UC(:,1:k)*UC(:,1:k)'*CTrain));
        
        svdEstimate = truncateTo01(svdEstimate);
        svdSmoothEstimate = truncateTo01(svdSmoothEstimate);
        svdSplitEstimate = truncateTo01(svdSplitEstimate);
        svdSplitEstimate2 = truncateTo01(svdSplitEstimate2);        
    else
        svdEstimate = rand(m,n);
        svdSmoothEstimate = sparse(m,n);
        svdLogitEstimate = sparse(m,n);
        svdSplitEstimate = sparse(m,n);
        svdSplitEstimate2 = sparse(m,n);
    end

    fid = fopen('log-scores', 'w'); fclose(fid); % Erase existing output file

%%
    % Standard collaborative filtering estimates
    opts = [];
    opts.writeToFile = 1;
    params.VTest = VTest; params.CTest = CTest;
    params.k = k;

    opts.MaxIter = MAX_ITER;

    if runWeightedSVD
        %C = truncateTo01(svdSmoothEstimate); [UCF,SCF,VCF] = svd(C); params.alphaInit = UCF(:,1:k)*sqrt(SCF(1:k,1:k)); params.betaInit = VCF(:,1:k)*sqrt(SCF(1:k,1:k))';
        %params.alphaInit = UE(:,1:k)*sqrt(SE(1:k,1:k)); params.betaInit = VE(:,1:k)*sqrt(SE(1:k,1:k));
        %params.alphaBiasInit = zeros(m,1); params.betaBiasInit = zeros(n,1);
        opts.loss = 'mse'; opts.dataTransform = 'none'; opts.estimateTransform = 'none'; [w, cfEstimate] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
        opts.loss = 'll'; opts.dataTransform = 'none'; opts.estimateTransform = 'none'; [w, cfLogEstimate] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        %params.alphaInit = UI(:,1:k)*sqrt(SI(1:k,1:k)); params.betaInit = VI(:,1:k)*sqrt(SI(1:k,1:k));
        %C = truncateTo01(cfEstimate); [UCF,SCF,VCF] = svd(log(C./(1 - C))); params.alphaInit = UCF(:,1:k)*sqrt(SCF(1:k,1:k)); params.betaInit = VCF(:,1:k)*sqrt(SCF(1:k,1:k))';
        %params.alphaInit = alpha0; params.betaInit = beta0;
        %params.alphaBiasInit = zeros(m,1); params.betaBiasInit = zeros(n,1);    
        opts.loss = 'mse'; opts.dataTransform = 'logit'; opts.estimateTransform = 'none'; [w, cfLogitEstimate] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);   
        opts.loss = 'll'; opts.dataTransform = 'logit'; opts.estimateTransform = 'none'; [w, cfLogLogitEstimate] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);   
        
        cfEstimate = truncateTo01(cfEstimate);
        cfLogEstimate = truncateTo01(cfLogEstimate);        
    else
        cfEstimate = sparse(m, n);
        cfLogEstimate = sparse(m, n);
        cfLogitEstimate = sparse(m, n);
        cfLogLogitEstimate = sparse(m, n);
    end

%%
	% Latent logistic regression estimate
	params = []; opts = [];
	l = 1;
	lrMSEEstimate = cell(0); lrMSEResEstimate = cell(0); lrMSESimEstimate = cell(0);
	lrLLEstimate = cell(0); lrLLResEstimate = cell(0); lrLLSimEstimate = cell(0);
	lrLLWeight = cell(0); lrLLResWeight = cell(0); lrLLSimWeight = cell(0);    

    opts.writeToFile = 1;

    params.k = k;
    params.VTest = VTest; params.CTest = CTest;

    % For initial weight, we'll let the latent features be large, and the
    % bias weights be small
    %w0 = [1/sqrt(k) * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1)];
    w0 = [1e-8 * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1); 1];
    params.wInit = w0;
    
    opts.MaxIter = MAX_ITER;
    opts.upperBound = 1.0;
    opts.sigType = 'scale'; opts.freezeWeights = [(m+n)*(k+q+1)+1];

    % Stores the parameter and options structs
    paramsOptsLFL = []; paramsOptsLFLRes = []; paramsOptsLFLSim = [];
    
%    w0 = [ 1e-2 1e-1 1e0 ]; % Magnitude of the initial weight

    for L = LAMBDA
        %disp('--- not using lambda for the moment, only poisson ---')

        params.lambdaU = lambdaU(L); params.lambdaV = lambdaV(L);
        params.lambdaPoisson = lambdaPoisson(L);

%        params.wInit = w0(1) * randn((m+n)*(k+q+1),1);
%        w0 = w0(2:end);
%        params.k = params.k + 5;
   
%%
        % Standard LFL model

        if runLFL
            % Initialize weights for LFL based on the logit SVD solution
            % SVD approx X ~= UV' is X ~= sig(log(UV'/(1 - UV')) ~= sig(alpha*beta')
            %params.alphaInit = UI(:,1:k)*sqrt(SI(1:k,1:k)); params.betaInit = VI(:,1:k)*sqrt(SI(1:k,1:k));

            %C = truncateTo01(cfEstimate); [UCF,SCF,VCF] = svd(log(C./(1 - C))); params.alphaInit = UCF(:,1:k)*sqrt(SCF(1:k,1:k)); params.betaInit = VCF(:,1:k)*sqrt(SCF(1:k,1:k));        
            %params.alphaBiasInit = zeros(m,1); params.betaBiasInit = zeros(n,1);

            % For the Poisson similarity constraint
            if isfield(optional, 'VPubParent')
                params.VPubParent = optional.VPubParent;
                params.CPubParent = optional.CPubParent;
                params.VAdParent = optional.VAdParent;
                params.CAdParent = optional.CAdParent;  
                
                opts.constraintType = 'poisson';
            end

            if noBias
%                 opts.freezeAlpha = 1;
%                 w0 = params.wInit;
%                 w0(1:m*k) = 1e8 * w0(1:m*k);
%                 params.wInit = w0;                

                disp('not using bias terms')
                opts.freezeAlphaBias = 1;
                opts.freezeBetaBias = 1;                
            end
            
            if 1
                disp('...using similarity for poisson...')
                params.alphaSPrior = alphaSPrior; params.betaSPrior = betaSPrior;
            end

            paramsOptsLFL.params = params; paramsOptsLFL.opts = opts;

            %opts.loss = 'mse'; [w, lrMSEEstimate{l}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
            opts.loss = 'll'; [lrLLWeight{l}, lrLLEstimate{l}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
            lrMSEEstimate{l} = sparse(m,n);
            
            if isfield(optional, 'VPubParent')
                params = rmfield(params, {'VPubParent' 'CPubParent' 'VAdParent' 'CAdParent'});
            end            
            if isfield(params, 'alphaSPrior')
                params = rmfield(params, {'alphaSPrior', 'betaSPrior'});
            end
        else
            lrMSEEstimate{l} = sparse(m,n);            
            lrLLEstimate{l} = lrMSEEstimate{l};
        end        

%%
        % LFL with residual fitting
        if runLFLResidual
            params.alphaPathRelation = alphaPathRelation;
            params.betaPathRelation = betaPathRelation;
            opts.multiplicativeHierarchy = 0;

            if opts.multiplicativeHierarchy
                disp('using multiplicative residual fitting')
            end            
            
            % We'll also include prior information when we do residual
            % fitting
            params.alphaSPrior = alphaSPrior;
            params.betaSPrior = betaSPrior;

            paramsOptsLFLRes.params = params; paramsOptsLFLRes.opts = opts;

            %opts.loss = 'mse'; [w, lrMSEResEstimate{l}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
            opts.loss = 'll'; [lrLLResWeight{l}, lrLLResEstimate{l}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
            %lrMSEResEstimate{l} = lrLLResEstimate{l};
            lrMSEResEstimate{l} = sparse(m,n);

            params = rmfield(params, 'alphaSPrior');
            params = rmfield(params, 'betaSPrior');

            opts.multiplicativeHierarchy = 0;
            params = rmfield(params, 'alphaPathRelation');
            params = rmfield(params, 'betaPathRelation');
        else
            lrMSEResEstimate{l} = sparse(m,n);
            lrLLResEstimate{l} = sparse(m,n);
        end

%%
        % LFL with similarity constraints

        lrMSESimEstimate{l} = cell(0); lrLLSimEstimate{l} = cell(0);
        lrMSESimWeight{l} = cell(0); lrLLSimWeight{l} = cell(0);

        ll = 1;
        for M = MU
            params.mu = M;

            opts.learnSimilarity = 0;

            lrMSESimEstimate{l}{ll} = cell(0); lrLLSimEstimate{l}{ll} = cell(0);
            lrMSESimWeight{l}{ll} = cell(0); lrLLSimWeight{l}{ll} = cell(0);

            lll = 1;
            for N = NU
                params.nu = N;

                if runLFLSimilarity
                    % Now use the similarity matrices to constraint the latent vectors
                    params.alphaSPrior = alphaSPrior; params.betaSPrior = betaSPrior;

                    % We'll also use path relationships
                    params.alphaPathRelation = alphaPathRelation;
                    params.betaPathRelation = betaPathRelation;                    

                    paramsOptsLFLSim.params = params; paramsOptsLFLSim.opts = opts;                    

                    %opts.loss = 'mse'; [w, lrMSESimEstimate{l}{ll}{lll}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
                    opts.loss = 'll'; [lrLLSimWeight{l}{ll}{lll}, lrLLSimEstimate{l}{ll}{lll}] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
                    %lrMSESimEstimate{l}{ll}{lll} = lrLLSimEstimate{l}{ll}{lll};
                    lrMSESimEstimate{l}{ll}{lll} = sparse(m,n);
                else
                    lrMSESimEstimate{l}{ll}{lll} = sparse(m,n);                    
                    lrLLSimEstimate{l}{ll}{lll} = sparse(m,n);                
                end

                lll = lll + 1;
            end

            opts.learnSimilarity = 0;

            ll = ll + 1;
        end

        if isfield(params, 'alphaSPrior'), params = rmfield(params, 'alphaSPrior'); end
        if isfield(params, 'betaSPrior'), params = rmfield(params, 'betaSPrior'); end

        if isfield(params, 'alphaPathRelation'), params = rmfield(params, 'alphaPathRelation'); end
        if isfield(params, 'betaPathRelation'), params = rmfield(params, 'betaPathRelation'); end

		l = l + 1;
    end

%%
    % Collect and output results
    estimates.empCTR = E;
    estimates.smoothCTR = ESmooth;
    estimates.rawSVD = svdEstimate;
    estimates.smoothSVD = svdSmoothEstimate;
    estimates.logitSVD = svdLogitEstimate;
    estimates.splitSVD1 = svdSplitEstimate;
    estimates.splitSVD2 = svdSplitEstimate2;
    estimates.weightedSVD = cfEstimate;
    estimates.weightedLogSVD = cfLogEstimate;    
    estimates.weightedLogitSVD = cfLogitEstimate;
    estimates.weightedLogLogitSVD = cfLogLogitEstimate;    
    estimates.lflMSE = lrMSEEstimate;
    estimates.lflLL = lrLLEstimate;
    estimates.lflMSERes = lrMSEResEstimate;
    estimates.lflLLRes = lrLLResEstimate;
    estimates.lflMSESim = lrMSESimEstimate;
    estimates.lflLLSim = lrLLSimEstimate;

    weights.lflLL = lrLLWeight;
    weights.lflLLRes = lrLLResWeight;
    weights.lflLLSim = lrLLSimWeight;

    paramsOpts.lflLL = paramsOptsLFL;
    paramsOpts.lflLLRes = paramsOptsLFLRes;
    paramsOpts.lflLLSim = paramsOptsLFLSim;

    %outputMask = logical([1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1]); % Which methods to display?
    outputMask = logical([1 1 0 0 0 0 0 0 0 0 0 0 1 0 1 0 1]); % Which methods to display?
    errorMask = logical([0 1 0 0 0]); % Which errors to display?

    lambdaStr = ''; muStr = ''; nuStr = '';
    for l = LAMBDA, lambdaStr = sprintf('%s %d', lambdaStr, l); end
    for m = MU, muStr = sprintf('%s %d', muStr, m); end
    for n = NU, nuStr = sprintf('%s %d', nuStr, n); end    
    disp(sprintf('lambda = %s', lambdaStr)); disp(sprintf('mu = %s', muStr)); disp(sprintf('nu = %s', nuStr))
    disp('all lambda values:'); disp(x)

	displayErrors(VTrain, CTrain, estimates, outputMask, errorMask);
    displayErrors(VTest, CTest, estimates, outputMask, errorMask);

%%
    % Plot train vs test objective function values
    if 0
        plotTrainTestObjectiveValues();
    end
