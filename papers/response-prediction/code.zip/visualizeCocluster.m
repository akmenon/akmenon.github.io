% Visualize the empirical CTR matrix across the training and test set after
% doing a kmeans clustering on the alpha and beta weights separately, and
% then using this to cocluster the matrix
% The hope is that by doing so, we get coclusters that are "meaningful":
% for example, if coclusters are either dense or sparse, that says that
% we've identified interesting groups of pubs/ads

w = w4; % Initialization from one of our other scripts, can change this to be any weight
[estimate, alpha, beta] = parseWeightVector(w, m, n, k, q, params, opts);

% Print out the log-likelihood of the given estimate
e = errorMeasures(estimate, VR, CR);
format short e
disp(sprintf('log-likelihood of estimate = %4.4f\n', e(2)))

VT = VT(:, 1:7779); CT = CT(:, 1:7779);
VR = VR(:, 1:7779); CR = CR(:, 1:7779);
beta = beta(1:7779,:);

% kmeans clustering on the alpha and beta's
% # of clusters must be determined empirically, as always
k1 = 3; k2 = 3;
[alphaID, C, D, alphaCDistance] = kmeansPP(alpha, k1); [betaID, C, D, betaCDistance] = kmeansPP(beta, k2);

alphaClusterCount = [];
betaClusterCount = [];
for i=1:k1, alphaClusterCount(i) = length(find(alphaID == i)); end;
for j=1:k2, betaClusterCount(j) = length(find(betaID == j)); end;

% Sort the clusters according to the number of members, so that we display
% the "heaviest" (co-)clusters first
% 
% [alphaClusterCount,alphaClusterSorted] = sort(alphaClusterCount, 'descend'); disp('alpha cluster sizes:'); disp(alphaClusterCount);
% [betaClusterCount,betaClusterSorted] = sort(betaClusterCount, 'descend'); disp('beta cluster sizes:'); disp(betaClusterCount);

% Sort clusters according to density i.e. sum of cluster distance / # of members
alphaClusterSum = zeros(k1, 1); betaClusterSum = zeros(k2, 1);
for i=1:k1, temp = find(alphaID == i); alphaClusterSum(i) = sum(alphaCDistance(temp, i))/length(temp); end;
for j=1:k2, temp = find(betaID == j); betaClusterSum(j) = sum(betaCDistance(temp, j))/length(temp); end;

[sumSort, alphaClusterSorted] = sort(alphaClusterSum);
[sumSort, betaClusterSorted] = sort(alphaClusterSum);
alphaClusterCount = alphaClusterCount(alphaClusterSorted);
betaClusterCount = betaClusterCount(betaClusterSorted);

% Internally sort based on distance to centroid
I = []; for i=1:k1, temp = find(alphaID == alphaClusterSorted(i)); [v,idx] = sort(alphaCDistance(temp, i)); temp = temp(idx); I = [ I; temp ]; end;
J = []; for j=1:k2, temp = find(betaID == betaClusterSorted(j)); [v,idx] = sort(betaCDistance(temp, j)); temp = temp(idx); J = [ J; temp ]; end;

% Visualize the coclustered data
E = (CT+CR)./max(1,VT+VR); % Empirical CTR on train + test
colormap(1-gray); imagesc(-log(1e-200+E(I,J)))

% Demarcate the coclusters for ease of visualization
v = cumsum(alphaClusterCount);
for i=1:length(unique(alphaID))-1
    h = line(1:7779,v(i)*ones(1,7779));
    set(h,'Color',[0.8 0.1 0.1],'LineStyle','--','LineWidth',4);
end

v = cumsum(betaClusterCount);
for j=1:length(unique(betaID))-1
    h = line(v(j)*ones(112,1),1:112);
    set(h,'Color',[0.8 0.1 0.1],'LineStyle','--','LineWidth',4);
end
