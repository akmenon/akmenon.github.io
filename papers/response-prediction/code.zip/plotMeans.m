function plotMeans(x, y, G, plotFormat, xAxisLabel, yAxisLabel, rescale, fontSize)

    if nargin < 3, G = 100; end;
    if nargin < 4, plotFormat = 'o-'; end;
    if nargin < 5, xAxisLabel = 'log(Views)'; end;
    if nargin < 6, yAxisLabel = 'Error'; end;
    if nargin < 7, rescale = 0; end; % Rescale y-axis to be capped by 1?
    if nargin < 8, fontSize = 18; end;

    if numel(x) == 0
        x = 1:length(y);
    end
    
    L = floor(length(x)/G);    
    xMean = mean(reshape(x(1:G*L), [L G]), 1);
    yMean = mean(reshape(y(1:G*L), [L G]), 1);
   
    if ~rescale
        plot(xMean, yMean, plotFormat, 'MarkerSize', 8, 'LineWidth', 2);
    else
        plot(xMean, yMean/max(yMean), plotFormat);
    end
    xlabel(xAxisLabel);
    ylabel(yAxisLabel);

    set(gca, 'FontSize', fontSize);
    set(get(gca, 'XLabel'), 'FontSize', fontSize);
    set(get(gca, 'YLabel'), 'FontSize', fontSize);
