function plotTrainTestObjectiveValues()

    close all;
    x = load('log-scores');

    if numel(x) > 0
        infs = find(x(:,1) == Inf);
        infs = [0; infs];

        for c = 1:length(infs)-1
            subplot(ceil((length(infs)-1)/2), 2, c)

            I = infs(c)+1:infs(c+1)-1;
            %trainObjRatio = x(I(1:end),1) ./ [x(I(1),1); x(I(1:end-1),1)];
            %testObjRatio = x(I(1:end),2) ./ [x(I(1),2); x(I(1:end-1),2)];

            trainObjRatio = x(I(1:end),1) ./ x(I(1),1);
            testObjRatio = x(I(1:end),2) ./ x(I(1),2);

            %[v,i] = min(testObjRatio);
            %disp(sprintf('test error minimized after %d iterations, = %d', i, v * x(I(1),2)))

            plot(trainObjRatio(25:end), 'bo-'); hold on; plot(testObjRatio(25:end),'ro-'); hold off;
        end
    end
