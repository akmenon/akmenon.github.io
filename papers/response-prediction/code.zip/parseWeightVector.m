% Given a raw weight vector, decompose it into the appropriate sub-weights
% Also compute the estimates of all the outputs given this weight
function [estimate, alpha, beta, alphaBias, betaBias, alphaS, betaS] = parseWeightVector(w, m, n, k, q, params, opts)

        if nargin < 7, opts = []; end;
        if ~isfield(opts, 'upperBound'), opts.upperBound = 1; end;

        alpha = reshape(w(1:m*k), [m k]);
        beta = reshape(w(m*k+1:m*k+n*k), [n k]);
        alphaBias = reshape(w((m+n)*k+1:(m+n)*k+m), [m 1]);
        betaBias = reshape(w((m+n)*k+m+1:(m+n)*(k+1)), [n 1]);
        alphaS = reshape(w((m+n)*(k+1)+1:(m+n)*(k+1)+m*q), [m q]);
        betaS = reshape(w((m+n)*(k+1)+m*q+1:(m+n)*(k+q+1)), [n q]);

        matEstimate = alpha * beta' + repmat(alphaBias, 1, n) + repmat(betaBias', m, 1);

        % Transform the estimate appropriately
        if isfield(opts, 'estimateTransform') && strcmp(opts.estimateTransform, 'none')
            estimate = matEstimate;
        elseif ~isfield(opts, 'estimateTransform') || strcmp(opts.estimateTransform, 'sigmoid') 
            estimate = sigmoid(matEstimate, opts.upperBound, [], opts.sigType);
        end

%         if strcmp(opts.dataTransform, 'logit')
%             estimate = sigmoid(matEstimate, opts.upperBound);
%         end
