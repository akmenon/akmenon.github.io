% If we have scores corresponding to the explicit, duplicated feature
% representation, then cut it down so that we only refer to the cells
function scores = removeScoreDuplicates(scores, V)

    V = cumsum(V);
    scores = scores(V);
