function plotEstimateHeatmap(VR,VT,CR,CT,estimate)

    % Sort estimates in decreasing order of score
    [m, n] = size(estimate);
    [v,i] = sort(estimate(:), 'descend');

    % Empirical CTRs on train and test set
    ATr = CT./max(1,VT);
    ATe = CR./max(1,VR);
    
    colormap(1 - gray);
    
    % Heatmap of the CTRs sorted by the score
    % Hope is that the darker regions are towards the top
    subplot(1, 2, 1);
    imagesc(reshape(ATr(i), [m n])');

    subplot(1, 2, 2);
    imagesc(reshape(ATe(i), [m n])');
