function displayErrors(V, C, estimates, outputMask, errorMask)

    NL = length(estimates.lflMSE); if NL > 0, NMu = length(estimates.lflMSESim{1}); if NMu > 0, NNu = length(estimates.lflMSESim{1}{1}); else NNu = 0; end; else NMu = 0; NNu = 0; end

    % We have to expand the output mask
    % Our inputs are at the cell level e.g. we say 'display the LFL MSE
    % results'
    % But internally we will expand the results for different lambda/mu
    % values
    % Just need to replicate the meta-choices to be more fine grained here
    expandedOutputMask = [outputMask(1:end-6) zeros(1,2*NL*(1+1+NMu*NNu))]; % 2NL plain LFL, 2NL residual LFL, 2NL*NMu*NNu relation regularized LFL
    expandedOutputMask(length(outputMask) - 6 + 1 : length(outputMask) - 6 + 2*NL) = reshape(repmat(outputMask(end-5:end-4)', [1 NL]), [2*NL 1])';    
    expandedOutputMask(length(outputMask) - 6 + 2*NL + 1 : length(outputMask) - 6 + 4*NL) = reshape(repmat(outputMask(end-3:end-2)', [1 NL]), [2*NL 1])';        
    expandedOutputMask(length(outputMask) - 6 + 4*NL + 1 : end) = reshape(repmat(outputMask(end-1:end)', [1 NL*NMu*NNu]), [2*NL*NMu*NNu 1])';

    expandedOutputMask = logical(expandedOutputMask);

	format short e;

    err = @(x) full(errorMeasures(x, V, C));
    errs = [ err(estimates.empCTR); err(estimates.smoothCTR); err(estimates.rawSVD); err(estimates.smoothSVD); err(estimates.logitSVD); err(estimates.splitSVD1); err(estimates.splitSVD2); err(estimates.weightedSVD); err(estimates.weightedLogSVD); err(estimates.weightedLogitSVD); err(estimates.weightedLogLogitSVD)];
    for l = 1:length(estimates.lflMSE)
        errs = [errs; err(estimates.lflMSE{l}); err(estimates.lflLL{l});];
    end

    for l = 1:length(estimates.lflMSE)
        errs = [errs; err(estimates.lflMSERes{l}); err(estimates.lflLLRes{l});];
    end
    
    for l = 1:length(estimates.lflMSE)    
        for ll = 1:length(estimates.lflMSESim{l})
            for lll = 1:length(estimates.lflMSESim{l}{ll})
                errs = [errs; err(estimates.lflMSESim{l}{ll}{lll}); err(estimates.lflLLSim{l}{ll}{lll}); ];
            end
        end
    end

    % Fill in method names
	methods = { 'Empirical CTR' 'Smooth CTR' 'Raw SVD' 'Smooth SVD' 'Logit SVD' 'Split SVD1' 'Split SVD2' 'Weighted SVD' 'Weighted SVD LL' 'Weighted Logit SVD' 'Weighted Logit SVD LL' };
    for i = 1:NL
		methods = [ methods sprintf('LFL-MSE l%d', i) sprintf('LFL-LL l%d', i) ];
    end

    for i = 1:NL
		methods = [ methods sprintf('LFL-MSE-Res l%d', i) sprintf('LFL-LL-Res l%d', i) ];
    end    
    
    for i = 1:NL
        for j = 1:NMu
            for k = 1:NNu
        		methods = [ methods sprintf('LFL-MSE-Sim l%d,m%d,n%d', i, j, k) sprintf('LFL-LSim l%d,m%d,n%d', i, j, k) ];
            end
        end
    end

	errs(:,end) = 1 - errs(:,end); % 1 - AUC is to be minimized

	% Display the methods in ranked order
    errs = errs(expandedOutputMask, :);
    methods = methods(expandedOutputMask);
    
    errs = errs(:, errorMask);
	[v,i] = sort(errs);
    methodsOut = reshape(methods(i), [sum(expandedOutputMask) sum(errorMask)]);
    
    for i = 1 : sum(expandedOutputMask)
        fprintf('%d\t%s\n', v(i,:), methodsOut{i})
    end
    fprintf('\n\n')

	format short;
