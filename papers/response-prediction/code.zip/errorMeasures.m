function error = errorMeasures(estimate, V, C)

	%labels = V(:) > 0;
	%auc = SampleError(estimate(:), labels, 'AUC');
        auc = 0;

	% Errors are only measurable when # of views > 0, so only focus on these examples
        I = (V ~= 0);
	estimate = estimate(I);
	C = C(I);
	V = V(I);

	truth = C ./ V;
	truth = truth(:);

	% At this stage everything is a long vector

	weightedMSE = sum((estimate - truth).^2 .* V)/sum(V);

	if sum((estimate <= 0) + (estimate >= 1)) == 0
		weightedLogistic = -mean(C .* log(estimate) +  (V - C) .* log(1 - estimate));
	else
		weightedLogistic = NaN;
	end
	over = sum(max(0, estimate - truth) .* V);
	under = sum(max(0, truth - estimate) .* V);

	error = [weightedMSE weightedLogistic over under auc];
