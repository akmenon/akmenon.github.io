% Given a latent feature representation for the corresponding view-click
% data, represent it as a standard supervised learning dataset by
% duplicating features and modifying the labels as appropriate
% We can select a subset of columns of V to do this for, via whichColumn
function [X, Y] = createExplicitDataset(alpha, alphaBias, V, C, whichColumn)

    [m, n] = size(V);

    if nargin < 5, whichColumn = [1:n]; end       

    X = zeros(sum(sum(V(:, whichColumn))), size(alpha, 2) + 1);
    Y = zeros(sum(sum(V(:, whichColumn))),1);
    
    c = 1;
    for i = 1:m
        for j = whichColumn
            for k = 1 : V(i,j)
                X(c,:) = [alpha(i, :) alphaBias(i)];
                Y(c) = (k <= C(i, j));
                
                c = c + 1;
            end
        end
    end
