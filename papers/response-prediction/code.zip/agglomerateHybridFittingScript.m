%%
[m,n] = size(VT);
k = 5;
q = 1;

if n == 11670
    numLeaves = 7779; % PVC
    mu = 1e4;
elseif n == 162551
    numLeaves = 162265; % Click 
elseif n == 13246
    numLeaves = 10000; % Click sampled
elseif n == 39220
    numLeaves = 27550; % PVC tensor
    mu = 2^6;
end

redoFirst = 0;
redoSecond = 0;
redoThird = 0;
redoFourth = 0;

ITERATIONS = 3; % Allow for loopback

for iteration = 1 : ITERATIONS
%%
    if redoFirst
        if iteration == 1
            params = []; opts = [];

            params.lambdaU = 0; params.lambdaV = 0;
            
            params.lambdaPoisson = 0; params.mu = 0;
            %params.lambdaPoisson = 1e-8; params.mu = 1e-200; disp('using estimate similarity constraints')

            % For initial weight, we'll let the latent features be large, and the
            % bias weights be small
            w0 = [1e-8 * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1); 1];
            params.wInit = w0;
        else
            params.wInit = w4; % Loopback!
        end

        params.k = k;
        params.VTest = VR; params.CTest = CR;

        opts.MaxIter = 5*150;
        opts.upperBound = 1.0;
        opts.loss = 'll';

        opts.sigType = 'scale';
        opts.freezeWeights = [(m+n)*(k+q+1)+1];

        params.alphaPathRelation = pubPathRelation;
        params.betaPathRelation = adPathRelation;

        VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;
        
        params.lambdaU = 1e-7; params.lambdaV = 1e-7;
        w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
    end

%%

    if redoSecond
        % Next we'll just learn the ad parent nodes' latent features

        opts.MaxIter = 350;
        params.wInit = w1;

        % Don't relearn the alpha's
        opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

        % Don't relearn the beta leaves in any form!
        freeze = zeros(n, k); freeze(1:numLeaves,:) = 1;
        opts.freezeWeights = [ opts.freezeWeights m*k + find(freeze)' ];
        opts.freezeWeights = [ opts.freezeWeights (m+n)*k + m + [1:numLeaves] ];

        VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
        w2 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        opts.freezeWeights = [];
    end

%%

    if redoThird
        % We'll use the agglomerated data to affect our publisher features
        % This will induce a "drowning" effect on the pub features...
        opts.MaxIter = 15;
        params.wInit = w2;

        % Don't relearn any of the beta's
        opts.freezeWeights = [ m*k+1:(m+n)*k+1 (m+n)*k+m+1:(m+n)*(k+1) (m+n)*(k+q+1)+1 ];
        
        VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;

        [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         for lp = 10.^[-5:5]
%             params.lambdaPoisson = lp;
%             [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         end        
        
        opts.freezeWeights = [];
    end

%%

    if redoFourth
        opts.MaxIter = 50;
        params.wInit = w3;

        % Don't relearn the alpha's
        %opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m ];

        params.alphaPathRelation = pubPathRelation;
        params.betaPathRelation = adPathRelation;

        params.alphaSPrior = speye(m);
        params.betaSPrior = adParents;
        params.mu = mu;

        VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;        
        
        opts.freezeWeights = [(m+n)*(k+q+1)+1];
        
        [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         for lp = 10.^[-5:5]
%             params.lambdaPoisson = lp;
%             [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         end

        opts.freezeWeights = [];
        params.betaSPrior = speye(n);
        params.mu = 0;
        params.lambdaPoisson = 0;
    end

end

%%

% Random ideas for trial

wasteland = 1;

if wasteland
    disp('wasteland')
    
for iteration = 1 : ITERATIONS
%%
        if iteration == 1
            params = []; opts = [];

            params.lambdaU = 0; params.lambdaV = 0;
            
            params.lambdaPoisson = 0; params.mu = 0;
            %params.lambdaPoisson = 1e-8; params.mu = 1e-200; disp('using estimate similarity constraints')

            % For initial weight, we'll let the latent features be large, and the
            % bias weights be small
            w0 = [1e-8 * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1); 1];
            params.wInit = w0;
        else
            params.wInit = w4; % Loopback!
        end

        params.k = k;
        params.VTest = VR; params.CTest = CR;

        opts.MaxIter = iter1;%5*150;
        opts.upperBound = 1.0;
        opts.loss = 'll';

        opts.sigType = 'scale';
        opts.freezeWeights = [(m+n)*(k+q+1)+1]; % No sigmoid parameter learning

        % At this stage itself, use parent nodes as bias terms we learn off
        % of
        params.alphaPathRelation = pubPathRelation;
        params.betaPathRelation = adPathRelation;

        % Only learn alpha, beta
        VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;

        params.lambdaU = 1e-7; params.lambdaV = 1e-7;
        w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

%%
        % Next we'll just learn the ad parent nodes' latent features

        opts.MaxIter = iter2; %;350;
        params.wInit = w1;

        % Don't relearn the alpha's
        opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

        % Don't relearn the beta leaves in any form!
        freeze = zeros(n, k); freeze(1:numLeaves,:) = 1;
        opts.freezeWeights = [ opts.freezeWeights m*k + find(freeze)' ];
        opts.freezeWeights = [ opts.freezeWeights (m+n)*k + m + [1:numLeaves] ];

        VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
        w2 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        opts.freezeWeights = [];

%%
        % We'll use the agglomerated data to affect our publisher features
        % This will induce a "drowning" effect on the pub features...
        opts.MaxIter = 15;
        params.wInit = w2;

        % Don't relearn any of the beta's
        opts.freezeWeights = [ m*k+1:(m+n)*k+1 (m+n)*k+m+1:(m+n)*(k+1) (m+n)*(k+q+1)+1 ];
        
        VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;

        [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         for lp = 10.^[-5:5]
%             params.lambdaPoisson = lp;
%             [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         end        
        
        opts.freezeWeights = [];

%%
        opts.MaxIter = 50;
        params.wInit = w3;

        % Don't relearn the alpha's
        %opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m ];

        params.alphaPathRelation = pubPathRelation;
        params.betaPathRelation = adPathRelation;

        params.alphaSPrior = speye(m);
        params.betaSPrior = adParents;
        params.mu = mu;

        VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;        
        
        opts.freezeWeights = [(m+n)*(k+q+1)+1];
        
        [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         for lp = 10.^[-5:5]
%             params.lambdaPoisson = lp;
%             [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%         end

        opts.freezeWeights = [];
        params.betaSPrior = speye(n);
        params.mu = 0;
        params.lambdaPoisson = 0;

end

%%
