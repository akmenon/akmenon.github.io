function [w1,w2,w3,w4,estimates] = agglomerateFittingScript(CT,CR,VT,VR,adParents)

    for l1 = [1e-9 1e-7 1e-5] %[0 1e-9 1e-8 1e-7 1e-6]
        for l2 = [0 l1]
            for l3 = [l1]
                for iter1 = [250 500]
                    for iter2 = [200 300 400]
                        for iter3 = [15 30]
                            for mu = [0 1e2 1e3 1e4]
                                for w0Norm = 10.^[-8]
                                    tic;
                                    estimates=PagglomerateFittingScript(CT,CR,VT,VR,adParents,l1,l2,l3,iter1,iter2,iter3,mu,w0Norm);
                                    error = errorMeasures(estimates, VR, CR); error = full(error(2));
                                    disp(sprintf('(%d, %d, %d, %d, %d, %d, %d, %d) -> %d [%d seconds]',l1,l2,l3,iter1,iter2,iter3,mu,w0Norm,error,toc));
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    

function [estimates,w1,w2,w3,w4] = PagglomerateFittingScript(CT,CR,VT,VR,adParents,l1,l2,l3,iter1,iter2,iter3,mu,w0Norm)

%%
[m,n] = size(VT);
k = 25;
q = 1;
ub = 1;

if n == 11670
    numLeaves = 7779; % PVC
    mu = 1e4;
elseif n == 165511
    numLeaves = 162265; % Click 
elseif n == 13246
    numLeaves = 10000; % Click sampled
elseif n == 39220
    numLeaves = 27550; % PVC tensor
    mu = 2^6;
end

stochastic = 0;

redoFirst = 0;
redoSecond = 0;
redoThird = 0;
redoFourth = 0;

ITERATIONS = 1; % Allow for loopback

for iteration = 1 : ITERATIONS
%%
    if redoFirst
        if iteration == 1
            params = []; opts = [];

            params.lambdaU = 0; params.lambdaV = 0; params.lambdaPoisson = 0;

            w0 = [1e-8 * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1); 1];
            params.wInit = w0;
        else
            params.wInit = w4; % Loopback!
        end

        params.k = k;
        params.VTest = VR; params.CTest = CR;

        if stochastic
            opts.MaxIter = 20 + 0*150;
            opts.upperBound = 1.0;
            opts.loss = 'll';
            opts.sigType = 'scale';
            
            opts.stochastic = 1; opts.eta = ETA;
            w0 = [1e-8 * randn((m+n)*(k),1); 1e-8 * randn((m+n)*(q+1),1); 1];        
            params.lambdaU = LU; params.lambdaV = LU;
            params.wInit = w0;

            opts.freezeWeights = [(m+n)*(k+q+1)+1]; % Don't learn exponent

            VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;
            w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);        

        else
            opts.freezeWeights = [(m+n)*(k+q+1)+1];

            opts.MaxIter = 1200/3;
            opts.upperBound = ub;
            opts.loss = 'll';
            opts.sigType = 'gompertz';

            VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;

            opts.sigType = 'scale';
            params.lambdaU = 1e-9; params.lambdaV = 1e-9;

            params.wInit(end) = -7;
            opts.sigType = 'threshold';
            opts.freezeWeights = [];
            
            for l = 10.^[-12:-9]
                params.lambdaU = l; params.lambdaV = l;
                w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
            end

%             for ub = [-10.5]
%                 params.wInit(end) = ub;
%                 opts.upperBound = ub;
% 
%                 opts.sigType = 'threshold';
%                 opts.freezeWeights = [];
% 
%                 w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);
%                 disp('--------------------------')
%             end



%             w1 = w0; w1(end) = 2.5;
% 
%             for i = 1 : 15
%                 params.wInit = w1;
% 
%                 opts.freezeWeights = [(m+n)*(k+q+1)+1];
% 
%                 opts.MaxIter = ceil(15 * sqrt(i));
%     %            opts.upperBound = UB;
%                 opts.loss = 'll';
%                 opts.sigType = 'power';
% 
%                 VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;
%                 w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);        
% 
%                 %%%
%                 opts.freezeWeights = [1:(m+n)*(k+q+1)];
%                 params.wInit = w1;
% 
%                 opts.MaxIter = 15;
%                 opts.loss = 'll';
% 
%                 VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;
%                 w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);        
% 
%                 opts.freezeWeights = [];
%             end
        end
    end

%%

    if redoSecond
        % Next we'll just learn the ad parent nodes' latent features

        opts.MaxIter = 300;
        params.wInit = w1;

        % Don't relearn the alpha's
        opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

        % Don't relearn the beta leaves in any form!
        freeze = zeros(n, k); freeze(1:numLeaves,:) = 1;
        opts.freezeWeights = [ opts.freezeWeights m*k + find(freeze)' ];
        opts.freezeWeights = [ opts.freezeWeights (m+n)*k + m + [1:numLeaves] ];

        %VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
        VTrain = [zeros(m,numLeaves) VT(:,numLeaves+1:end)]; CTrain = [zeros(m,numLeaves) CT(:,numLeaves+1:end)];
        w2 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        opts.freezeWeights = [];
    end

%%

    if redoThird
        % We'll use the agglomerated data to affect our publisher features
        % This will induce a "drowning" effect on the pub features...
        opts.MaxIter = 15;
        params.wInit = w2;

        % Don't relearn any of the beta's
        opts.freezeWeights = [ m*k+1:(m+n)*k+1 (m+n)*k+m+1:(m+n)*(k+1) (m+n)*(k+q+1)+1 ];

        %VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
        VTrain = [zeros(m,numLeaves) VT(:,numLeaves+1:end)]; CTrain = [zeros(m,numLeaves) CT(:,numLeaves+1:end)];        
        [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        opts.freezeWeights = [];
    end

%%

    if redoFourth
        % We relearn the beta's with the similarity constraints imposed

        opts.MaxIter = 15;
        params.wInit = w3;

        % Don't relearn the alpha's
        opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

        params.alphaSPrior = speye(m);
        params.betaSPrior = adParents;

        params.mu = mu;

        VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;

        [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

        opts.freezeWeights = [];
        params.betaSPrior = speye(n);
        params.mu = 0;
    end

end

%%

% testing area, not related to the above

wasteland = 1;

if wasteland
   
    for iteration = 1 : ITERATIONS
    %%
            if iteration == 1
                params = []; opts = [];

                params.lambdaU = 0; params.lambdaV = 0; params.lambdaPoisson = 0;

                w0 = [w0Norm * randn((m+n)*(k),1); w0Norm * randn((m+n)*(q+1),1); 1];
                params.wInit = w0;
            else
                params.wInit = w4; % Loopback!
            end

            params.k = k;
            params.VTest = VR; params.CTest = CR;

            opts.freezeWeights = [(m+n)*(k+q+1)+1];

            opts.MaxIter = iter1; %1200/3;
            opts.upperBound = ub;
            opts.loss = 'll';
            opts.sigType = 'gompertz';

            % No parent nodes at all
            VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;

            %params.lambdaU = 1e-9; params.lambdaV = 1e-9;
            params.lambdaU = l1; params.lambdaV = l1;            

            params.wInit(end) = -7;
            opts.sigType = 'threshold';
            opts.freezeWeights = [ (m+n)*(k+q+1)+1 ]; % No threshold learning

            w1 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

    %%
            % Next we'll just learn the ad parent nodes' latent features

            opts.MaxIter = iter2; %300;
            params.wInit = w1;
            params.lambdaU = l2; params.lambdaV = l2;

            % Don't relearn the alpha's
            opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

            % Don't relearn the beta leaves in any form!
            freeze = zeros(n, k); freeze(1:numLeaves,:) = 1;
            opts.freezeWeights = [ opts.freezeWeights m*k + find(freeze)' ];
            opts.freezeWeights = [ opts.freezeWeights (m+n)*k + m + [1:numLeaves] ];

            %VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
            VTrain = [zeros(m,numLeaves) VT(:,numLeaves+1:end)]; CTrain = [zeros(m,numLeaves) CT(:,numLeaves+1:end)];
            w2 = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

            opts.freezeWeights = [];          
            
    %%
            % We'll use the agglomerated data to affect our publisher features
            % This will induce a "drowning" effect on the pub features...
            opts.MaxIter = iter3; %15;
            params.wInit = w2;
            params.lambdaU = l3; params.lambdaV = l3;

            % Don't relearn any of the beta's
            opts.freezeWeights = [ m*k+1:(m+n)*k+1 (m+n)*k+m+1:(m+n)*(k+1) (m+n)*(k+q+1)+1 ];

            %VTrain = VT; CTrain = CT; VTrain(:,1:numLeaves) = 0; CTrain(:,1:numLeaves) = 0;
            VTrain = [zeros(m,numLeaves) VT(:,numLeaves+1:end)]; CTrain = [zeros(m,numLeaves) CT(:,numLeaves+1:end)];        
            [w3, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

            opts.freezeWeights = [];

    %%
            % We relearn the beta's with the similarity constraints imposed

            opts.MaxIter = 15;
            params.wInit = w3;

            % Don't relearn the alpha's
            opts.freezeWeights = [ 1:m*k (m+n)*k+1:(m+n)*k+m (m+n)*(k+q+1)+1 ];

            params.alphaSPrior = speye(m);
            params.betaSPrior = adParents;

            params.mu = mu;

            VTrain = VT; CTrain = CT; VTrain(:,numLeaves+1:end) = 0; CTrain(:,numLeaves+1:end) = 0;

            [w4, estimates] = weightedLROptimizer(m, n, k, q, VTrain, CTrain, params, opts);

            opts.freezeWeights = [];
            params.betaSPrior = speye(n);
            params.mu = 0;
    end
end

%%
