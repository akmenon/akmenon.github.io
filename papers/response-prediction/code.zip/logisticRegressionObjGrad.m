function [F, dF] = logisticRegressionObjGrad(w, X, Y, lambda)

    [n,d] = size(X);
    w0 = w(2:end);

    F = (lambda/2) * sum(w0.^2) + sum(log(1 + exp(X * w0 + w(1))) - Y .* (X * w0 + w(1)));
    
    dFBias = sum(1./(1 + exp(-(X * w0 + w(1)))) - Y);
    dFRest = lambda * w0 + sum(repmat((1./(1 + exp(-(X * w0 + w(1)))) - Y), 1, d) .* X)';
    dF = [dFBias; dFRest];
