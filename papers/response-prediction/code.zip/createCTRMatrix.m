function [ Truth, Sample, Clicks, Views ] = createCTRMatrix(m, n, kTrue)

	% Random matrix of probabilities
%	Truth = rand(m, n);
%	disp('uniform random Truth');

	% Random but with latent sigmoidal structure
	if nargin < 3, kTrue = 5; end

	Truth = 1./(1 + exp(5.5 + (2*rand(m,kTrue) - 1) * (2*rand(kTrue,n) - 1)));
	disp('latent rare sigmoid Truth');

%	Truth = 1./(1 + exp(-randn(m, kTrue) * (1./randn(kTrue, n))));
%	disp('latent Cauchy sigmoid Truth');

%	Truth = 1./(1 + exp(-randn(m, kTrue) * randn(kTrue, n)));
%	disp('latent normal^2 sigmoid Truth');

	% Random view counts
	% For the moment, we'll assume that the true number of views is at least 1
	MAX_VIEWS = 100;
        Views = ceil(MAX_VIEWS * rand(m, n));

%	MEAN_VIEWS = 4;
%	Views = 1 + poissrnd(MEAN_VIEWS, m, n);
%	disp('poisson views');

%	Views = ceil(1./rand(m, n));
%	disp('inverse uniform views');

%	R = rand(m, n);
%	Views = (R > 0.9) .* (1 + poissrnd(4, m, n)) + (R < 0.9) .* (1 + poissrnd(99, m, n));
%	disp('bimodal poisson')

%	Views = ones(m,n);
%	disp('constant views');

	% Clicks are modelled as Bernoulli trials on each view (unrealistic, but this is a synthetic dataset!)
        for i = 1:m
		for j = 1:n
			Clicks(i, j) = binornd(Views(i, j), 0.5 * (1 + rand) * Truth(i, j));
		end
	end

	% Empirical sample is just the fraction of clicks to views
	Sample = Clicks ./ Views;
