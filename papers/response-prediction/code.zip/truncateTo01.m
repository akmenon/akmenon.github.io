function X = truncateTo01(X, I)

    if nargin == 1
        Y = X(:);
    else
        Y = X(I);
        Y = Y(:);
    end

    if max(Y) < 1 - eps && min(Y) > eps && isfinite(sum(Y.^2))
        return;
    end

    outOfBounds = (eps < X) .* (X < 1 - eps);
    notNum = isnan(X);
    infinite = ~isfinite(X);

    % Use the row mean for entries that don't lie in [0, 1]
    % Row mean of course excludes these entries
    Xgood = outOfBounds .* X;
    Xgood(notNum) = 0;
    Xgood(infinite) = 0;

    M = mean(Xgood, 2) + eps;
    M = repmat(M, 1, size(X, 2));

    I = Xgood == 0;
    X(I) = M(I);

% Fail-safe approach for when the above is too slow on sparse matrices
% for i = 1:m
%     rowMean(i) = mean(CT(i,VT(i,:)>0)./max(1,VT(i,VT(i,:)>0)));
%     bad = (VR(i,:) > 0 & (E(i,:) == 0 | E(i,:) == 1));
%     X(i,bad) = max(1e-200, rowMean(i));
% end;
