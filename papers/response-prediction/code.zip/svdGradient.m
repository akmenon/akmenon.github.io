function [F, dF] = svdGradient(w, V, C, freeze)

    [m, n] = size(V);
    k = numel(w)/(m+n);

    alpha = reshape(w(1:m*k), [m k]);
    beta = reshape(w(1+m*k:(m+n)*k), [n k]);

    X = C./max(1, V);
    F = sum(sum((X - alpha * beta').^2));

    dAlpha = 2 * (alpha*beta' - X) * beta;
    dBeta = 2 * (alpha*beta' - X)' * alpha;
    
    dF = [dAlpha(:); dBeta(:)];
    
    if nargin < 4, freeze = zeros((m+n)*k,1); end
    dF = dF .* (1 - freeze);
