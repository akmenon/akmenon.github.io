function viewPlotScript(VT, MLE, P, modelName)

%     ET = CT./max(1,VT);
% 
%     numLeaves = 7779;
%     %numLeaves = 10000;
% 
%     ET = ET(:,1:numLeaves);
%     P = P(:,1:numLeaves);
%     VT = VT(:,1:numLeaves);
%     CT = CT(:,1:numLeaves);
    
    x = VT; % Training set views as x-axis
    
    train = 1;

    % Ratio on training set
    if train
        y = log((1e-200 + MLE)./P); % Log of truth-vs-prediction
        I = (MLE > 0); % Ignore entries with empirical CTR 0

    % Ratio on test set
    else
        y = log((1e-200 + ER)./P); % Log of truth-vs-prediction
        I = (CR > 0); % Ignore entries with empirical CTR 0
    end

    x = x(I); y = y(I);
    [v,i] = sort(x); % Sort views in ascending order
    x = v; y = y(i);

    %I = (x < 100);
    %x = x(I); y = y(I);
    x = log10(x);

    %plot((x), y, 'o-')
    %plotMeans(x, y, round(length(y)/25), 'o-')
    plot(x,smooth(y,10,'loess'),'o-')
    hold on;
    plot(x, zeros(size(x)), 'k-.', 'LineWidth', 3);
    hold off;
    xlabel('log(Training set views)'); ylabel('log(CTR / Prediction)');
    ylim([-3.5 3.5]);
    legend({ modelName 'Optimal' });

    xlabel('Training set views'); set(gca,'XTick',[]);

    FONT_SIZE = 32;
    set(gca,'FontSize',FONT_SIZE);
    set(get(gca, 'XLabel'),'FontSize',FONT_SIZE);
    set(get(gca, 'YLabel'),'FontSize',FONT_SIZE);
