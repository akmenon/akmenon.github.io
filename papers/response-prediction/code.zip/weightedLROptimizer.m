function [w, estimate, alpha, beta, alphaBias, betaBias, alphaS, betaS] = weightedLROptimizer(m, n, k, q, V, C, params, opts)

    clear global;
    global bestW; global bestWIteration; global bestTestError; global bestWeightedLROutput;
    bestW = []; bestTestError = Inf;

    if isfield(params, 'wInit'), w0 = params.wInit; else w0 = randn((m+n)*(k+q+1)+1,1); end

    if nargin < 6, params = []; end;
    if nargin < 7, opts = []; end;

	if isfield(params, 'alphaInit') && numel(params.alphaInit) > 0, w0(1:m*k) = params.alphaInit(:); end
	if isfield(params, 'betaInit') && numel(params.betaInit) > 0, w0(m*k+1:(m+n)*k) = params.betaInit(:); end
	if isfield(params, 'alphaBiasInit') && numel(params.alphaBiasInit) > 0, w0((m+n)*k+1:(m+n)*k+m) = params.alphaBiasInit(:); end
	if isfield(params, 'betaBiasInit') && numel(params.betaBiasInit) > 0, w0((m+n)*k+m+1:(m+n)*(k+1)) = params.betaBiasInit(:); end

    if isfield(opts, 'freezeAlphaBias'), w0((m+n)*k+1:(m+n)*k+m) = 0; end;
    if isfield(opts, 'freezeBetaBias'), w0((m+n)*k+m+1:(m+n)*(k+1)) = 0; end;

    % Duplicated here because we need it when parsing the weight vector...
    if ~isfield(opts, 'dataTransform'), opts.dataTransform = 'none'; end;
    if ~isfield(opts, 'estimateTransform'), opts.estimateTransform = 'sigmoid'; end;

    % Transformation of the data matrix that is used
    if strcmp(opts.dataTransform, 'logit')
        params.dataMatrix = C ./ max(1, V);
        params.dataMatrix(V > 0) = log((1e-8 + params.dataMatrix(V>0))./(1-params.dataMatrix(V>0)+1e-8));        
    elseif strcmp(opts.dataTransform, 'none')
        params.dataMatrix = C ./ max(1, V);
    end
    
    if ~isfield(opts, 'writeToFile'), opts.writeToFile = 0; end;

%     mypath = path;
%     if ~strcmp(mypath(end-6:end), 'minFunc')
%         path(path, '~/adityame/minFunc');
%     end

    options.Display = 'off';

    if ~isfield(opts, 'MaxIter'), opts.MaxIter = 100; end;    
    options.MaxIter = opts.MaxIter; options.MaxFunEvals = opts.MaxIter;

    params.k = k; params.q = q;    
    
    if isfield(params, 'VTest')
        options.outputFcn = @(x,y,z,varargin) evaluateSolution(x,y,m,n,k,q,varargin{:});
    
        % Evaluate the initial solution
        %disp('evaluating initial solution...')
        evaluateSolution(w0, [], m, n, k, q, V, C, params, opts);
    end
    
    % If we've specified a noisy gradient, then just use gradient descent for optimization
    if isfield(opts, 'stochastic') && opts.stochastic
        opts.outputFcn = options.outputFcn;
        w = gradientDescent(w0, V, C, params, opts);
    else
        optimizer = @minFunc;

        tic;
        warning off MATLAB:nearlySingularMatrix; % LBFGS typically complains about this

        % Block coordinate descent or plain?
        totIterations = 0; totEvals = 0;
        if ~(~isfield(opts, 'bcd') || opts.bcd == 0)
            disp('optimizing with block coordinate descent')

            % We only implement 2-block coordinate descent
            % We can optionally pass in two "freeze schemes" that specify the
            % two blocks, else we'll define the blocks to be the entire alpha
            % and beta weights
            while 1
                if ~isfield(opts, 'freezeWeights')
                    params.freezeBeta = 1; params.freezeBetaBias = 1;
                else
                    opts.freezeWeights = opts.freeze1;
                end
                [w,f,exitFlag,output] = optimizer(@weightedLR, w0, options, V, C, params, opts);

                i1 = output.iterations; f1 = output.funcCount;

                fprintf(1, 'updated block 1...')

                w0 = w;
                if ~isfield(opts, 'freezeWeights')
                    params.freezeAlpha = 1; params.freezeAlphaBias = 1;
                else
                    opts.freezeWeights = opts.freeze2;
                end
                [w,f,exitFlag,output] = optimizer(@weightedLR, w0, options, V, C, params, opts);

                fprintf(1, 'updated block 2...')

                i2 = output.iterations; f2 = output.funcCount;

                totIterations = totIterations + i1 + i2;
                totEvals = totEvals + f1 + f2;

                % Stop when we've gone on for too long, or when we've
                % converged (i.e. both optimizations don't perform any steps)
                if (totIterations >= 10 * options.MaxIter) || (max(i1, i2) <= 1)
                    fprintf(1, '\n')
                    break
                end
            end
        else
            %disp('simultaneous optimization')
            [w,f,exitFlag,output] = optimizer(@weightedLR, w0, options, V, C, params, opts);
            totIterations = output.iterations; totEvals = output.funcCount;
        end    
       % disp(sprintf('lbfgs finished in %d seconds with %d iterations/%d evaluation; %s', toc, totIterations, totEvals, output.message))    
    end

    % Purely a delimiter when we make multiple runs
    if opts.writeToFile
        fid = fopen('log-scores', 'a');
        fprintf(fid, 'Inf Inf\n');
        fclose(fid);
    end

    % Use the best weight vector in terms of minimizing test error
    if numel(bestW) > 0, w = bestW; end; %disp(sprintf('best test error, %d, was achieved after %d iterations', bestTestError, bestWIteration)); end;        

    if numel(bestWeightedLROutput) >  0
        estimate = bestWeightedLROutput.estimate;
        alpha = bestWeightedLROutput.alpha;
        beta = bestWeightedLROutput.beta;
        alphaBias = bestWeightedLROutput.alphaBias;
        betaBias = bestWeightedLROutput.betaBias;
        alphaS = bestWeightedLROutput.alphaS;
        betaS = bestWeightedLROutput.betaS;
    else
        disp('parsing the weight vector myself...')
        [estimate, alpha, beta, alphaBias, betaBias, alphaS, betaS] = parseWeightVector(w, m, n, k, q, params, opts);
    end
    
	%disp(sprintf('||alpha||_F^2 = %4.4f, ||beta||_F^2 = %4.4f; ||alpha_b||_2^2 = %4.4f, ||beta_b||_2^2 = %4.4f', norm(alpha, 'fro')^2, norm(beta, 'fro')^2, norm(alphaBias, 'fro')^2, norm(betaBias, 'fro')^2))

    clear global;


function [ trainError, testError ] = evaluateSolution(w, infoStruct, m, n, k, q, VTrain, CTrain, params, opts, varargin)

    global bestW; global bestWIteration; global bestTestError;
    global weightedLROutput; global bestWeightedLROutput;
    
    if numel(weightedLROutput) == 0
    	estimate = parseWeightVector(w, m, n, k, q, params, opts);
%        disp('*** not using best solution ***')        
%        disp('*** using best solution ***')        
    else
        estimate = weightedLROutput.estimate;
    end

    if strcmp(opts.dataTransform, 'logit')
        estimate = sigmoid(estimate);
    end
    
%    estimate = truncateTo01(estimate, (VTrain + params.VTest > 0));

    %trainError = errorMeasures(estimate, VTrain, CTrain);    
    trainError = [ Inf Inf Inf Inf Inf ];
    testError = errorMeasures(estimate, params.VTest, params.CTest); 
    
    % Pick out one individual error measure
    trainError = full(trainError(2));
    testError = full(testError(2));

%    if opts.writeToFile, fid = fopen('log-scores', 'a'); else, fid = 1; end
    if opts.writeToFile
        fid = fopen('log-scores', 'a');
        fprintf(fid, '%4.8f %4.8f\n', trainError, testError);
        fclose(fid);
    end
    
    % Keep track of the best weight vector in terms of minimizing the test
    % error
    if 0 || (testError <= bestTestError)
        if (testError < bestTestError)
            %disp(sprintf('new best: %4.4f, with sigmoid power = %4.4f', testError, w(end)));
        else
            %disp('constant test error')
        end
        bestTestError = testError;
        bestW = w;
        if numel(infoStruct) > 0, bestWIteration = infoStruct.iteration; else bestWIteration = 0; end;
        bestWeightedLROutput = weightedLROutput;        
    else
        %disp(sprintf('worse test error: %4.4f -> %4.4f', bestTestError, testError))
    end

%    if opts.writeToFile, fclose(fid); end
