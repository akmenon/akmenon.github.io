function [F,dF] = postMLEOptimizer(theta, C, V, rawEstimate)

    a = 2;
    e = 1e-100;

    S = sigmoid(a * (V - exp(theta)));
    P = (C > 0) .* (S .* (C./max(1,V)) + (1 - S) .* rawEstimate);
    F = -full(sum(sum((V > 0) .* (C .* log(P + e) + (V - C) .* log(1 + e - P)))));

    dP = (C > 0) * a * exp(theta) .* S .* (1 - S) .* (C./max(1,V) - rawEstimate);
    dF = full(sum(sum((V > 0) .* (dP .* (C - V .* P) ./ ((P + e) .* (1 + e - P))))));
