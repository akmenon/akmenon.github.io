function plotErrorsVsViews(VR, CR, estimate)

    I = (VR > 0);
    VR = VR(I);
    CR = CR(I);
    estimate = estimate(I);
    
    %test = CR./VR;    
    %MSE = (estimate(I) - test(I)).^2;
    LL = -(CR .* log(estimate) + (VR - CR) .* log(1 - estimate));

    [x,i] = sort(VR);
    y = LL(i); %y = MSE(i);
   
%    plotMeans(log10(x), cumsum(y)/length(y), length(y))
    plotMeans(log10(x), y, length(y))

%    hold on
%    plotMeans(log10(x), test(i)); hold on; plotMeans(log10(x), estimate(i), 100, 'ro-');
%    plotMeans(log10(x), min(5000, test(i)./estimate(i)));
