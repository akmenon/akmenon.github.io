[estimate, alpha, beta] = parseWeightVector(w, m, n, k, q, params, opts);

VT = VT(:, 1:7779); CT = CT(:, 1:7779);
VR = VR(:, 1:7779); CR = CR(:, 1:7779);
beta = beta(1:7779,:);
estimate = estimate(:,1:7779);

E = estimate;
M = log(estimate./(1-estimate));
VS = VR + VT; CS = CR + CT;
R = full(CS./max(1,VS));

[v,I] = sort(R(:));
% [M,I] = sort(M(:));

VS = VS(I); CS = CS(I); M = M(I); E = E(I); R = R(I);

I = VS > 0;
VS = VS(I); CS = CS(I); M = M(I); E = E(I); R = R(I);

plotMeans(1:numel(R), R, 871248/336, 'o-')
% hold on
% plotMeans(M, E, 100, 'ro-', '', '')
% hold off

% plotMeans(M,R./E,100,'o-')
