% Weighted logistic regression to predict Pr[C|V]
% Inputs:
% - weight vector w, comprising weights alpha for the rows, beta for the columns, plus biases for both;
% - matrices V, C comprising the views and clicks in the training set
% - parameters in params, comprising:
%   * k, the number of latent features
%   * q, the rank of the similarity matrices
%	* lambdaU/V, the L2 regularization parameter of row/column latent features
%   * lambdaPoisson, tradeoff parameter for Poisson CDF constraint
%   * mu, the parameter controlling similarity in latent space
%   * nu, the regularization parameter of the similarity matrix
%   * alpha/betaSPrior, the Wishart mean on the similarity matrices
%   * alpha/betaPathRelation, specifiying path relationships between the latent vectors, for residual fitting
%
% - options in opts, comprising:
%	* freezeAlpha/Beta, whether or not to freeze the alpha/beta weights during optimization
%   * freezeAlphaBias/BetaBias, as above for the bias weights
%   * freezeAlphaSim/BetaSim, as above for the similarity matrix
%   * freezeWeights, indices of weights to be frozen; more general than any of the above
%   * learnSimilarity, whether to learn the similarity matrix or to just use the given prior
% 	* estimateTransform = { 'none', 'sigmoid' }, the transformation applied to the raw matrix approximation alpha * beta'
%	* loss = { 'mse', 'mae', 'll', 'poissll' }, the loss function used for training
%   * constraintType = { 'poisson', 'coarse-square', 'fine-square' }, the type of constraint placed on model predictions via the hierarchy
%   * clusterBias, whether we should use a very simplistic cluster bias model instead of the full hierarchy model
%   * upperBound, the upper cap on the sigmoid output
%   * multiplicativeHierarchy, whether the latent vectors for hierarchy nodes are combined multiplicatively or additively
%   * multiplicativeType, the type of multiplicative hierarchy: { 'plain', 'fallback'}
%   * stochastic, whether we return a stochastic version of the gradient so that we can use stochastic gradient descent
function [F, dF] = weightedLR(w, V, C, params, opts)

    global weightedLROutput; % Don't see how to make minFunc accept other output apart from function/gradient

    if nargin < 4, params = []; end;
    if nargin < 5, opts = []; end;

    [m, n] = size(V);

    if ~isfield(params, 'k'), k = -1; else k = params.k; end;
    if ~isfield(params, 'q'), q = 1; else q = params.q; end;
    if ~isfield(params, 'lambdaU'), lambdaU = 0; else lambdaU = params.lambdaU; end; % By default, no L2 regularization
    if ~isfield(params, 'lambdaV'), lambdaV = 0; else lambdaV = params.lambdaV; end;
    if ~isfield(params, 'lambdaPoisson'), params.lambdaPoisson = 0; end;
    if ~isfield(params, 'mu'), mu = 0; else mu = params.mu; end;
    if ~isfield(params, 'nu'), nu = 0; else nu = params.nu; end;
    if ~isfield(params, 'alphaSPrior'), if mu > 0, alphaSPrior = speye(m)/m; end; else alphaSPrior = params.alphaSPrior/m; end; % Divide by m so that the mean value equals the given matrix
    if ~isfield(params, 'betaSPrior'), if mu > 0, betaSPrior = speye(n)/n; end; else betaSPrior = params.betaSPrior/n; end;

    if ~isfield(params, 'alphaPathRelation'), alphaPathRelation = speye(m); else alphaPathRelation = params.alphaPathRelation; end;
    if ~isfield(params, 'betaPathRelation'), betaPathRelation = speye(n); else betaPathRelation = params.betaPathRelation; end;

    if ~isfield(params, 'dataMatrix'), dataMatrix = C ./ max(1, V); else dataMatrix = params.dataMatrix; end;

    if ~isfield(opts, 'freezeAlpha'), opts.freezeAlpha = 0; end;
    if ~isfield(opts, 'freezeBeta'), opts.freezeBeta = 0; end;
    if ~isfield(opts, 'freezeAlphaBias'), opts.freezeAlphaBias = 0; end;
    if ~isfield(opts, 'freezeBetaBias'), opts.freezeBetaBias = 0; end;
    if ~isfield(opts, 'freezeAlphaSim'), opts.freezeAlphaSim = 0; end;
    if ~isfield(opts, 'freezeBetaSim'), opts.freezeBetaSim = 0; end;
    if ~isfield(opts, 'freezeWeights'), opts.freezeWeights = []; end;
    
    if ~isfield(opts, 'learnSimilarity'), opts.learnSimilarity = 0; end;
    if ~isfield(opts, 'estimateTransform'), opts.estimateTransform = 'sigmoid'; end;
    if ~isfield(opts, 'loss'), opts.loss = 'll'; end;
    if ~isfield(opts, 'upperBound'), opts.upperBound = 1.0; end;
    if ~isfield(opts, 'sigType'), sigType = 'scale'; else sigType = opts.sigType; end;
    
    if ~isfield(opts, 'clusterBias'), opts.clusterBias = 0; end;
    if ~isfield(opts, 'multiplicativeHierarchy') || opts.multiplicativeHierarchy == 0,
        opts.multiplicativeHierarchy = 0;
        if ~isfield(opts, 'constraintType'), opts.constraintType = 'fine-square'; end;
        else if ~isfield(opts, 'multiplicativeType'), opts.multiplicativeType = 'fallback'; end;
    end;
    if ~isfield(opts, 'stochastic'), opts.stochastic = 0; end;
      
    if ~opts.learnSimilarity
        opts.freezeAlphaSim = 1;
        opts.freezeBetaSim = 1;
        nu = 0;
    end
    
	% For debugging
	%disp('input summary:')
	%disp(sprintf('lambda = %4.4f, loss = %s, transform = %s, freezeAlpha =	%%d, freezeBeta = %d', params.lambda, opts.loss, opts.transform, opts.freezeAlpha, opts.freezeBeta))

	alpha = reshape(w(1:m*k), [m k]);
	beta = reshape(w(m*k+1:m*k+n*k), [n k]);
	alphaBias = reshape(w((m+n)*k+1:(m+n)*k+m), [m 1]);
	betaBias = reshape(w((m+n)*k+m+1:(m+n)*(k+1)), [n 1]);
    alphaS = reshape(w((m+n)*(k+1)+1:(m+n)*(k+1)+m*q), [m q]);
    betaS = reshape(w((m+n)*(k+1)+m*q+1:(m+n)*(k+1+q)), [n q]);

    upperBound = w((m+n)*(k+q+1)+1);
    opts.upperBound = upperBound;
    
    if opts.freezeAlphaBias, alphaBias = zeros(m, 1); end;
    if opts.freezeBetaBias, betaBias = zeros(n, 1); end;

    if opts.stochastic
        % Pick a random index among the nonzero views
        [I,J] = find(V);
        r = ceil(rand * length(I));
        ir = I(r);
        jr = J(r);

        % Only this index is set to be nonzero for this iteration
        V = sparse([ir; m], [jr; n], [V(ir, jr); 0]);
        C = sparse([ir; m], [jr; n], [C(ir, jr); 0]);
    end


%%
	dTransform = [];
    mySigmoid = @(x) sigmoid(x, opts.upperBound, [], sigType);

    if ~opts.multiplicativeHierarchy
        if ~opts.clusterBias
            if ~opts.stochastic
                matEstimate = (alphaPathRelation * alpha) * (betaPathRelation * beta)' + repmat(alphaPathRelation * alphaBias, 1, n) + repmat((betaPathRelation * betaBias)', m, 1);
            else
                matEstimate = sparse([ir; m], [jr; n], [(alphaPathRelation(ir,:) * alpha) * (betaPathRelation(jr,:) * beta)' + alphaPathRelation(ir,:) * alphaBias + (betaPathRelation(jr,:) * betaBias)'; 0]);
                %matEstimate = [ matEstimate zeros(size(matEstimate, 1), n - size(matEstimate, 2)); zeros(m - size(matEstimate, 1), n) ];
            end
        else
            % Only a simple cluster bias
            matEstimate = alpha * beta' + repmat(alphaPathRelation * alphaBias, 1, n) + repmat((betaPathRelation * betaBias)', m, 1);
        end
    else
        % Fallback inspired multiplication
        if strcmp(opts.multiplicativeType, 'fallback')
            L = log(mySigmoid(alpha * beta' + repmat(alphaBias, 1, n) + repmat(betaBias', m, 1)));
            matEstimate = exp(alphaPathRelation * L * betaPathRelation');          
            matEstimate = log(matEstimate ./ (1 - matEstimate)); % Needed because estimate is defined as sigmoid(matEstimate)

        elseif strcmp(opts.multiplicativeType, 'plain')
            % Straightforward multiplication
            E1 = real(exp(alphaPathRelation * log(alpha)));
            E2 = real(exp(betaPathRelation * log(beta)));

            matEstimate = E1 * E2';
            fullAlphaBias = repmat(alphaPathRelation * alphaBias, 1, n);
            fullBetaBias = repmat(betaPathRelation * betaBias, 1, m)';
            matEstimate = matEstimate + fullAlphaBias + fullBetaBias;
        end
    end

    [iC, jC, vC] = find(C);
    [iV, jV, vV] = find(V - C);

    % Compute matrix approximation for nonzero clicks and nonzero views - clicks
    matEstimate0 = matEstimate(sub2ind(size(matEstimate), iC, jC));
    matEstimate1 = matEstimate(sub2ind(size(matEstimate), iV, jV));

    if strcmp(opts.estimateTransform, 'sigmoid')
        % Now let's cut out all but the essential cells        
        if ~opts.stochastic
            indicator = V;
            if isfield(params, 'VTest'), indicator = indicator + params.VTest; end;
            indicator = (indicator > 0);

            estimate = sigmoid(matEstimate, opts.upperBound, indicator, sigType);
        else
            estimate = mySigmoid(matEstimate);
        end

        dTransform = @(X,Y) dSigmoid(X, opts.upperBound, Y, sigType);

        estimate0 = mySigmoid(matEstimate0);
        estimate1 = mySigmoid(matEstimate1);
%         estimate = accumarray([iV jV], estimate1);

    elseif strcmp(opts.estimateTransform, 'none')
    	estimate = matEstimate;
    	dTransform = @dLinear;
        
        estimate0 = matEstimate0;
        estimate1 = matEstimate1;

    end

    estimate = [ estimate zeros(size(estimate, 1), size(C,2) - size(estimate,2)) ];

%%
    % Reconstruction error part of objective
    if strcmp(opts.loss, 'mse')
        F = sum(sum(V .* (dataMatrix - estimate).^2));
        AA = 2 * V .* (estimate - dataMatrix) .* dTransform(matEstimate, estimate);

    elseif strcmp(opts.loss, 'mae')
        F = sum(sum(V .* abs(estimate - dataMatrix)));
        AA = V .* sign(estimate - dataMatrix) .* dTransform(matEstimate, estimate);

    elseif strcmp(opts.loss, 'll')
        warning off MATLAB:log:logOfZero;

        % Code for dense version
%        dTrans = dTransform(matEstimate, estimate);
%        negEstimate = 1 - estimate;
%		F = -sum(sum(C .* log(estimate) + (V - C) .* log(negEstimate)));
%        AA = -C .* dTrans ./ estimate + (V - C) .* dTrans ./ negEstimate;

        negEstimate = 1 - estimate1;
        dTrans0 = dTransform(matEstimate0, estimate0);
        dTrans1 = dTransform(matEstimate1, estimate1);

        F = -(sum(vC .* log(estimate0(:))) + sum(vV .* log(negEstimate(:))));

warning off MATLAB:divideByZero

        xC = -vC .* dTrans0 ./ estimate0;
        xV = vV .* dTrans1 ./ negEstimate;
        
        AA = sparse([iC; iV; m], [jC; jV; n], [xC; xV; 0]);
        
    elseif strcmp(opts.loss, 'poissll')
        warning off MATLAB:log:logOfZero;

        F = sum(sum(V .* estimate - C .* log(estimate)));
        AA = dTransform(matEstimate, estimate) .* (V - C ./ estimate);
    end

    F = F / nnz(V);

    if ~opts.multiplicativeHierarchy        
        if ~opts.clusterBias
            % Standard additive model
            dAlpha = alphaPathRelation' * AA * betaPathRelation * beta / nnz(V);
            dBeta = (AA * betaPathRelation)' * alphaPathRelation * alpha / nnz(V);
        else
            % Simple cluster bias only
            dAlpha = AA * beta / nnz(V);
            dBeta = (AA)' * alpha / nnz(V);
        end

        dAlphaBias = sum(alphaPathRelation' * AA, 2) / nnz(V);
        dBetaBias = sum(AA * betaPathRelation, 1)' / nnz(V);

    else
        % Fallback inspired approach
        if strcmp(opts.multiplicativeType, 'fallback')
            S = 1 - mySigmoid(alpha * beta' + repmat(alphaBias, 1, n) + repmat(betaBias', m, 1));

            estimate = [estimate zeros(size(estimate,1),size(V,2) - size(estimate,2))];
            A = (C - (V - C) .* estimate ./ (1 - estimate));

            % MEX call for efficiency
            [dAlpha, dBeta, dAlphaBias, dBetaBias] = fallbackgradient(alphaPathRelation, betaPathRelation, full(A), full(S), alpha, beta);                        
            
            dAlpha = -dAlpha/nnz(V);
            dBeta = -dBeta/nnz(V);
            dAlphaBias = -dAlphaBias/nnz(V);
            dBetaBias = -dBetaBias/nnz(V);            
        
        % Standard multiplicative model
        elseif strcmp(opts.multiplicativeType, 'plain')
            dAlpha = alphaPathRelation' * (E1 .* (AA * E2)) ./ (nnz(V) * alpha);
            dBeta = betaPathRelation' * (E2 .* (AA' * E1)) ./ (nnz(V) * beta);

            dAlphaBias = sum(alphaPathRelation' * AA, 2) / nnz(V);
            dBetaBias = sum(AA * betaPathRelation, 1)' / nnz(V);
        end
    end

%%
    % L2 regularization of latent vectors
    % Regularization will push the nodes to predict similarly to their
    % parents

    if lambdaU > 0 && lambdaV > 0
        % Regularization weighted by the number of views: many views => don't regularize so much, few views => regularize a lot
        % We normalize the number of views to be based on 1, so that the regularization doesn't require huge lambda values to kick in
        S1 = max(1,sum(V, 1)'); S2 = max(1,sum(V, 2)); S1 = S1/max(S1); S2 = S2/max(S2);
       
        DAlpha = S2.^(-1/2); DBeta = S1.^(-1/2);
        F = F + (lambdaU/2) * norm(alpha .* repmat(sqrt(DAlpha), 1, k), 'fro')^2 + (lambdaV/2) * norm(beta .* repmat(sqrt(DBeta), 1, k), 'fro')^2;

        dAlpha = dAlpha + lambdaU * alpha .* repmat(DAlpha, 1, k);
        dBeta = dBeta + lambdaV * beta .* repmat(DBeta, 1, k);
    end

%%
    % Relation/similarity based regularization

    % Compute pairwise L2 distance between latent vectors
    % Also include the bias term for the pairwise distance   
    if mu > 0
        if opts.learnSimilarity
            % Compute actual similarity based on low rank approximations
            alphaSimilarity = alphaS * alphaS';
            betaSimilarity = betaS * betaS';    
        else
            alphaSimilarity = alphaSPrior;
            betaSimilarity = betaSPrior;
        end

        alphaExt = [alpha alphaBias];
        betaExt = [beta betaBias];

        [iA,jA,vA] = find(alphaSimilarity);
        [iB,jB,vB] = find(betaSimilarity);

        alphaPairwise = sum((alphaExt(iA, :) - alphaExt(jA, :)).^2, 2);
        betaPairwise = sum((betaExt(iB, :) - betaExt(jB, :)).^2, 2);
        
        F = F + (mu/2) * (sum(vA .* alphaPairwise) + sum(vB .* betaPairwise));

        dAlpha = dAlpha + 2 * mu * (repmat(sum(alphaSimilarity, 2), 1, k) .* alpha - alphaSimilarity * alpha);
        dBeta = dBeta + 2 * mu * (repmat(sum(betaSimilarity, 2), 1, k) .* beta - betaSimilarity * beta);

        dAlphaBias = dAlphaBias + 2 * mu * (sum(alphaSimilarity, 2) .* alphaBias - alphaSimilarity * alphaBias);
        dBetaBias = dBetaBias + 2 * mu * (sum(betaSimilarity, 2) .* betaBias - betaSimilarity * betaBias);
    end

    if opts.learnSimilarity
        dAlphaS =  mu * alphaPairwise * alphaS;
        dBetaS = mu * betaPairwise * betaS;
    else
        dAlphaS = zeros(size(alphaS));
        dBetaS = zeros(size(betaS));
    end

%%    
    % Wishart prior on similarity matrices
    if nu > 0
        alphaSPriorInv = inv(alphaSPrior);
        betaSPriorInv = inv(betaSPrior);

        F = F + nu * (sum(sum(alphaSimilarity .* alphaSPriorInv)) + sum(sum(betaSimilarity .* betaSPriorInv)));

        dAlphaS = dAlphaS  + 2 * nu * alphaSPriorInv * alphaS;
        dBetaS = dAlphaS  + 2 * nu * betaSPriorInv * betaS;
    end

%%

    % Constraint on estimates

    if ~opts.multiplicativeHierarchy && params.lambdaPoisson > 0
        % (Normal approximation to) Poisson probabilistic penalty
        if strcmp(opts.constraintType, 'poisson')
            a = full(sqrt(sum(V)/2)); % 1 x n
            b = params.VAdParent'; % 1 x n
            c = params.CAdParent'; % 1 x n

            c1 = repmat(sqrt(b)./max(1, a.*sqrt(c)), m, 1) .* V;
            c2 = repmat(sqrt(c)./max(1, a.*sqrt(b)), m, 1) .* V;

            erfInput = full(sum(c1 .* estimate - c2)); % 1 x n
            F = F - params.lambdaPoisson * sum(erf(erfInput));

            x1 = c1 .* estimate .* (1 - estimate); % m x n
            x2 = exp(-erfInput.^2)'; % n x 1

            dAlpha =  dAlpha - params.lambdaPoisson * (2/sqrt(pi)) * (alphaPathRelation' * x1 * (repmat(x2, 1, k) .* (betaPathRelation * beta)));
            dAlphaBias = dAlphaBias - params.lambdaPoisson * (2/sqrt(pi)) * (alphaPathRelation' * x1 * (x2 .* ones(n, 1)));

            dBeta = dBeta - params.lambdaPoisson * (2/sqrt(pi)) * (betaPathRelation' * (x1'.* repmat(x2, 1, m)) * (alphaPathRelation * alpha));
            dBetaBias = dBetaBias - params.lambdaPoisson * (2/sqrt(pi)) * (betaPathRelation' * (x1'.* repmat(x2, 1, m)) * ones(m, 1));

        % Direct squared error penalty on estimates
        elseif strcmp(opts.constraintType, 'coarse-square')
            betaSimilarity = betaSPrior;

            s1 = sum(estimate); % 1 x n
            E = estimate .* (1 - estimate);

            %F = F + params.lambdaPoisson * sum(sum(betaSimilarity .* (repmat(s1, n, 1) - repmat(s1', 1, n)).^2));        
            [iB, jB, vB] = find(betaSimilarity);
            F = F + params.lambdaPoisson * sum(vB .* (s1(iB) - s1(jB))'.^2);

            dAlpha = dAlpha + params.lambdaPoisson * 4 * alphaPathRelation' * E * (betaPathRelation * beta .* (repmat(s1' .* sum(betaSimilarity, 2), 1, k) - betaSimilarity * repmat(s1', 1, k)));
            dAlphaBias = dAlphaBias + params.lambdaPoisson * 4 * alphaPathRelation' * E * (ones(n, 1) .* (s1' .* sum(betaSimilarity, 2) - betaSimilarity * s1'));

            dBeta = dBeta + params.lambdaPoisson * 4 * betaPathRelation' * ((E' * alphaPathRelation * alpha) .* repmat((sum(betaSimilarity, 2) .* s1' - betaSimilarity' * s1'), 1, k));
            dBetaBias = dBetaBias + params.lambdaPoisson * 4 * betaPathRelation' * ((E' * ones(m,1)) .* ((sum(betaSimilarity, 2) .* s1' - betaSimilarity' * s1')));

        % Fine grained squared error penalty
        elseif strcmp(opts.constraintType, 'fine-square')
            betaSimilarity = betaSPrior;
            [iB, jB, vB] = find(betaSimilarity);

            F = F + params.lambdaPoisson * sum(vB' .* sum((estimate(:,iB) - estimate(:,jB)).^2));

            E = dTransform(matEstimate, estimate); %estimate .* (1 - estimate);

            dAlpha = dAlpha + params.lambdaPoisson * 4 * alphaPathRelation' * (repmat(sum(betaSimilarity), m, 1) .* estimate .* E - E .* (estimate * betaSimilarity)) * (betaPathRelation * beta);
            dAlphaBias = dAlphaBias + params.lambdaPoisson * 4 * alphaPathRelation' * (repmat(sum(betaSimilarity), m, 1) .* estimate .* E - E .* (estimate * betaSimilarity)) * ones(n, 1);

            dBeta = dBeta + params.lambdaPoisson * 4 * betaPathRelation' * (repmat(sum(betaSimilarity)', 1, m) .* (estimate .* E)' - ((estimate * betaSimilarity) .* E)') * alphaPathRelation * alpha;
            dBetaBias = dBetaBias + params.lambdaPoisson * 4 * betaPathRelation' * (repmat(sum(betaSimilarity)', 1, m) .* (estimate .* E)' - ((estimate * betaSimilarity) .* E)') * ones(m, 1);
        end
    end

%%
    % Gradient of upper bound
    if strcmp(sigType, 'power')
        Ebar0 = estimate0.^(1/upperBound);    
        Ebar1 = estimate1.^(1/upperBound);

        dx0 = (1 - Ebar0) * log(2) / ((1 - 2^(-1/upperBound)) * upperBound);
        dx1 = (1 - Ebar1) * log(2) / ((1 - 2^(-1/upperBound)) * upperBound);        

        dUpperBound = -(sum(sum((log(Ebar0) + dx0) .* vC)) - sum(sum((log(Ebar1) + dx1) .* vV .* estimate1 ./ negEstimate)))/nnz(V);
    elseif strcmp(sigType, 'scale')
        Ebar0 = estimate0/upperBound;
        Ebar1 = estimate1/upperBound;
        dUpperBound = -(sum(sum(Ebar0 .* vC ./ estimate0)) - sum(sum(Ebar1 .* vV ./ negEstimate)))/nnz(V);
    elseif strcmp(sigType, 'gompertz')
        dUpperBound = 0; % TODO: proper implementation
    elseif strcmp(sigType, 'threshold')
    	dUpperBound = -(sum(sum(vC .* (1 - estimate0))) - sum(sum(vV .* estimate1)))/nnz(V);
    end

%%

    % Final gradient!
	dF = [~opts.freezeAlpha * dAlpha(:); ~opts.freezeBeta * dBeta(:); ~opts.freezeAlphaBias * dAlphaBias(:); ~opts.freezeBetaBias * dBetaBias(:); ...
          ~opts.freezeAlphaSim * dAlphaS(:); ~opts.freezeBetaSim * dBetaS(:); dUpperBound(:)];
    dF = full(dF);
    dF(opts.freezeWeights) = 0;
    

%%
    % Store parsed data for other methods to use
    weightedLROutput = [];
    weightedLROutput.estimate = estimate;
    weightedLROutput.alpha = alpha;
    weightedLROutput.beta = beta;
    weightedLROutput.alphaBias = alphaBias;
    weightedLROutput.betaBias = betaBias;
    weightedLROutput.alphaS = alphaS;
    weightedLROutput.betaS = betaS;
  
%%
    
function df = dSigmoid(X, a, S, type)
    if nargin == 1, a = 1; end;
    if nargin < 3, disp('unspecified sigmoid'); S = sigmoid(X, a); end;
    if nargin < 4, type = 'scale'; end;

    if strcmp(type, 'scale')
    	df = S .* (1 - S/a); % Take into account the a term carefully
    elseif strcmp(type, 'power')
        df = a * S .* (1 - (sigmoid(X, a, [], 'power')).^(1/a));
    elseif strcmp(type, 'gompertz')
        r = 1e3;
        df = a * S * log(r * a) .* exp(-a * X);
    elseif strcmp(type, 'threshold')
	df = S .* (1 - S);
    end

function df = dLinear(X, varargin)
	df = ones(size(X));
