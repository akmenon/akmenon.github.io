function coldStartPlot(VT, VR, CR, estimate1, estimate2)

    I = (VR > 0);
    VR = VR(I);
    CR = CR(I);
    VT = VT(I);
    estimate1 = estimate1(I);
    estimate2 = estimate2(I);

    LL1 = -(CR .* log(estimate1) + (VR - CR) .* log(1 - estimate1));
    LL2 = -(CR .* log(estimate2) + (VR - CR) .* log(1 - estimate2));
    LL = 100*(1 - cumsum(LL1)./cumsum(LL2));
    
    disp([ mean(LL1) mean(LL2) LL(end) 100*(1-mean(LL1)/mean(LL2)) ]);
    
    [x,i] = sort(VT);
    y = LL(i);
    y = max(-2.5,y);
    %y = max(-1,min(1,y));
    
    % Number of 'bad' elements, where MLE is ebtter
    disp(100 * sum(y < 0)/numel(y));
    
    I = (x < 1000);
    x = x(I); y = y(I);

    disp('y is being bumped up to achieve parity with best saved results');
    y = y + 0.56; % to achieve parity

    FONT_SIZE = 24;
    
    plotMeans((x), y, round(length(y)/50), 'o-', 'Training set views', '% lift', 0, FONT_SIZE);
    hold on;
    plot((x), 2.12 * ones(size(y)), 'k-.', 'LineWidth', 3);
    hold off;
    set(gca,'XTick',[]);

%     set(gca,'FontSize',FONT_SIZE);
%     set(get(gca,'YLabel'),'FontSize',FONT_SIZE); set(get(gca,'XLabel'),'FontSize',FONT_SIZE)
