% Trains the LFL model for the given training set of (user, movie,
% rating) triplets in the Tr structure using SGD
% Returns latent features in the weight structure
% Tr and Te = train/test structs with vectors 'u' for users, 'm' for movies, 'r' for
% ratings
% k = # of latent features (default 5)
% eta = initial learning rate (default 0.01)
% lambda = strength of regularization (default 0)
% epochs = # of epochs to train for (default 15)
% loss = type of loss function; supported losses are 'mse' (default), 'mae', 'smooth-mae' and 'log' 
%        'log' is suitable for problems with nominal/unordered labels
% wInit = initial value of weight vector (default Gaussian random)
% epochsPerTest = # of epochs to wait before computing the test set error (default 1, every epoch)
function [w, trainErrors, testErrors] = lflSGDOptimizer(Tr, Te, k, eta, lambda, epochs, loss, wInit, epochsPerTest)

    users = Tr.u; movies = Tr.m; ratings = Tr.r;
    
    % Shuffle training set
    n = length(users);
    I = randperm(n);
    Tr.u = Tr.u(I); Tr.m = Tr.m(I); Tr.r = Tr.r(I);

    % Figure out number of users/movies and number of possible ratings
    U = max(users) - min(users) + 1;
    M = max(movies) - min(movies) + 1;
    R = max(ratings) - min(ratings) + 1;

    % Default values for parameters
    if nargin < 3, k = 5; end
    if nargin < 4, eta = 0.01;end
    if nargin < 5, lambda = 0; end
    if nargin < 6, epochs = 15; end
    if nargin < 7, loss = 'mse'; end
    if nargin < 9, epochsPerTest = 1; end    

    baseClass = 1; % Fix the features of one rating to be 0?
    singleUserWeight = 1; % Just one set of user weights for each rating?

    if nargin < 8
        userW = 1/k * randn(k, R, U); % # of latent features x # of possible ratings x # of users
        movieW = 1/k * randn(k, R, M);

        % Fix a latent weight to be 1 so that we have user/movie biases
        % We will make the 1st feature of the movies and the last of the
        % users be biases, hence the counterparts need to be 1
        % cf Improving Maximum Margin Matrix Factorization, Weimer et al
        userW(1,:,:) = 1;
        movieW(end,:,:) = 1;

        % Fix one of the ratings' weights to be uniformly 0
        % We'll pick rating #1 by default so e.g. for ratings that are
        % binary {0,1}, we will only have a weight for outcome '1'
        if baseClass
            % If all user weights are the same, doesn't make sense for it
            % to have a base class
            if ~singleUserWeight, userW(:,1,:) = 0; end;
            movieW(:,1,:) = 0;
        end
    else
        userW = wInit.userW;
        movieW = wInit.movieW;
    end

    % For simplicity we'll keep around a full set of weights, and ensure
    % they are duplicated
    % TODO: avoid this and just store a single weight
    if singleUserWeight, userW(1:end-1,2:end,:) = repmat(userW(1:end-1,1,:), [1 R-1 1]); end

    disp(sprintf('training for %d epochs with %d latent features', epochs, k))    
    disp(sprintf('regularization = %d, eta = %d', lambda, eta))
    disp(sprintf('loss is %s', loss))

    for e = 1 : epochs
        etaCurr = eta/e; % Per-epoch dampening of learning rate
%        etaCurr = 0.9 * eta; % Alternative dampening scheme

        for index = 1 : n
            u = users(index); m = movies(index); r = ratings(index);

            uW = userW(:,:,u);
            mW = movieW(:,:,m);

            % Forced bias, just to be certain
            % TODO: remove this, don't think it's necessary!
            uW(1,:) = 1;
            mW(end,:) = 1;      

            % Vector whose ith element is Pr[rating = i | u, m; w]
            p = exp(diag(uW' * mW));
            p = p/sum(p);
            p = p';

            if strcmp(loss, 'log')
                
                I = ((1:R) == r); % I(y = z) in the paper
                Gu = bsxfun(@times, mW, (p - I));
                Gm = bsxfun(@times, uW, (p - I));
                
            else
                % Take expected rating as the prediction
                prediction = sum((1:R) .* p);

                if strcmp(loss, 'mae')
                    s = sign(prediction - r);
                elseif strcmp(loss, 'smooth-mae')
                    temp = (prediction - r);
                    s = (abs(temp) < 0.5) .* temp/0.5 + (1 - (abs(temp) < 0.5)) .* sign(temp);
                elseif strcmp(loss, 'mse')
                    s = 2 * (prediction - r);                
                end

                G = s * p .* ((1:R) - prediction);
                Gu = bsxfun(@times, mW, G);
                Gm = bsxfun(@times, uW, G);           
            end
            
            % Regularization
            % Doesn't affect the bias term (nor the constant '1' term)
            Gu(2:end-1,:) = Gu(2:end-1,:) + lambda * uW(2:end-1,:);
            Gm(2:end-1,:) = Gm(2:end-1,:) + lambda * mW(2:end-1,:);
            
            % Constant '1' feature for bias stays a '1'
            Gu(1,:) = 0;
            Gm(end,:) = 0;

            if baseClass
                Gu(:,1) = 0;
                Gm(:,1) = 0;
            end

            % For single user weights, everything gets modified by the
            % same amount
            % That amount requires us to sum over gradients for the
            % individual ratings
            if singleUserWeight, Gu(1:end-1,:) = repmat(sum(Gu(1:end-1,:), 2), [1 R]); end;

            userW(:,:,u) = uW - etaCurr * Gu;
            movieW(:,:,m) = mW - etaCurr * Gm;              
            
        end

        % If learning rate is too high, weights can blow up
        if isnan(norm(userW(:), 'fro')) || isnan(norm(movieW(:), 'fro'))
            disp('early stop!')
            break
        end        
        
        if numel(Te) > 0 && mod(e, epochsPerTest) == 0
            w = constructWeight(userW, movieW);

            trainErrors = testModel(@lflPredictor, w, Tr);
            testErrors = testModel(@lflPredictor, w, Te);
            disp(sprintf('\n train/test 0-1 error = %4.4f / %4.4f, rmse = %4.4f / %4.4f, mae = %4.4f / %4.4f', trainErrors.zoe, testErrors.zoe, trainErrors.rmse, testErrors.rmse, trainErrors.mae, testErrors.mae))
        end
    end

    w = constructWeight(userW, movieW);
    if numel(Te) > 0 && ~(isnan(norm(userW(:), 'fro')) || isnan(norm(movieW(:), 'fro')))
        trainErrors = testModel(@lflPredictor, w, Tr);
        testErrors = testModel(@lflPredictor, w, Te);
    else
        trainErrors = [];
        testErrors = [];
    end


function w = constructWeight(userW, movieW)

    w = [];
    w.userW = userW; w.userW(1,:,:) = 1;
    w.movieW = movieW; w.movieW(end,:,:) = 1;
