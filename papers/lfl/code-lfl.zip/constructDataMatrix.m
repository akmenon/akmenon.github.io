function data = constructDataMatrix(Tr, Te)

    if nargin == 2
        data = sparse([Tr.u; Te.u], [Tr.m; Te.m], [Tr.r; Te.r]);
    else
        data = sparse(Tr.u, Tr.m, Tr.r);
    end
