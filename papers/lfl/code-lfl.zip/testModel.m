% Evalutes learnt model on test data
% Returns an error structure with 0-1 error, mean absolute error, and RMSE
function [errors, probabilities, predictions, truth] = testModel(myPredictor, w, Te)

    errors = [];
    dataTe = constructDataMatrix(Te);
    n = length(Te.u);

    % Check if entries are real-valued or not
    roundR = round(Te.r);
    
    % Integer valued
    if norm(Te.r - roundR, 'fro') < 1e-4    
        R = max(2, length(unique(Te.r)));

        [predictions, argmaxPredictions, fullProbabilities] = myPredictor(w);
        predictions = nonzeros(predictions .* (dataTe > 0));
        argmaxPredictions = nonzeros(argmaxPredictions .* (dataTe > 0));

        % Compute the probabilities
        probabilities = zeros(nnz(dataTe), R);        
        for r = 1:R
            probabilities(:,r) = nonzeros(bsxfun(@times, squeeze(fullProbabilities(:,:,r)), dataTe > 0));
        end
        
        truth = nonzeros(dataTe);

        errors.zoe = sum(argmaxPredictions ~= truth)/n;
        errors.mae = sum(abs(round(predictions) - truth))/n;
        errors.rmse = sqrt(sum((predictions - truth).^2)/n);      

    % Real-valued, just compute everything and then pick out the test ones
    else
        predictions = (dataD > 0) .* (squeeze(w.userW)' * squeeze(w.movieW));

        errors.zoe = full(sum(sum(predictions ~= dataD))/n);
        errors.mae = full(sum(sum(abs(predictions - dataD)))/n);
        errors.rmse = full(sqrt(sum(sum((predictions - dataD).^2))/n));
    end
