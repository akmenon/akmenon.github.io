% Predictions from the LFL model using the given weight vector
% This is computed over all users and movies (which are implicit in the weight)
% Output consists of the real-valued predictions (expected value under the
% probability model); discrete valued  'argmax predictions', viz the most
% likely label under the probability model; and the actual probabilities
% themselves
function [predictions, argmaxPredictions, probabilities] = lflPredictor(w)

    R = size(w.userW, 2);
    U = size(w.userW, 3);
    M = size(w.movieW, 3);

    % When R is small, faster to have an explicit loop with matrix algebra
    % inside
    probabilities = zeros(U, M, R);
    for r = 1:R
        uW = squeeze(w.userW(:,r,:));
        mW = squeeze(w.movieW(:,r,:));
        probabilities(:,:,r) = exp(uW' * mW);
    end
    probabilities = bsxfun(@rdivide, probabilities, sum(probabilities, 3));

    predictions = sum(bsxfun(@times, reshape(1:R, [1 1 R]), probabilities), 3);
    [v, argmaxPredictions] = max(probabilities, [], 3);
